import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Pencil, Trash2, Loader2 } from 'lucide-react';
import { EditDoctorForm } from './edit-doctor-form';

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  qualifications: string;
  bio: string;
  image_url: string;
}

export function AdminDoctorsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [doctorToDelete, setDoctorToDelete] = useState<number | null>(null);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  
  const { data: doctors, isLoading, error } = useQuery({
    queryKey: ['/api/doctors'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/doctors');
      return response.json();
    }
  });
  
  const deleteDoctor = useMutation({
    mutationFn: async (doctorId: number) => {
      return apiRequest('DELETE', `/api/doctors/${doctorId}`);
    },
    onSuccess: () => {
      toast({
        title: 'Doctor deleted',
        description: 'The doctor has been removed from the system.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/doctors'] });
      setIsDeleteDialogOpen(false);
      setDoctorToDelete(null);
    },
    onError: (error) => {
      console.error('Error deleting doctor:', error);
      toast({
        title: 'Error',
        description: 'There was an error deleting the doctor. Please try again.',
        variant: 'destructive',
      });
    }
  });
  
  const handleDelete = (doctorId: number) => {
    setDoctorToDelete(doctorId);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (doctorToDelete) {
      deleteDoctor.mutate(doctorToDelete);
    }
  };
  
  const handleEdit = (doctor: Doctor) => {
    setEditingDoctor(doctor);
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-40">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-4 bg-red-50 text-red-800 rounded-md">
        Error loading doctors. Please try again.
      </div>
    );
  }
  
  return (
    <div>
      {editingDoctor ? (
        <div className="space-y-4 p-4">
          <Button 
            variant="outline" 
            size="sm" 
            className="mb-4 text-primary border-primary/30 hover:bg-primary/10"
            onClick={() => setEditingDoctor(null)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="mr-2 h-4 w-4">
              <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
            Back to list
          </Button>
          <EditDoctorForm 
            doctor={editingDoctor} 
            onComplete={() => {
              setEditingDoctor(null);
              queryClient.invalidateQueries({ queryKey: ['/api/doctors'] });
            }}
          />
        </div>
      ) : (
        <>
          {doctors && doctors.length > 0 ? (
            <Table className="admin-table">
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Specialty</TableHead>
                  <TableHead>Qualifications</TableHead>
                  <TableHead className="w-24 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {doctors.map((doctor: Doctor) => (
                  <TableRow key={doctor.id}>
                    <TableCell className="font-medium">{doctor.name}</TableCell>
                    <TableCell>
                      <span className="doctor-specialty">{doctor.specialty}</span>
                    </TableCell>
                    <TableCell>{doctor.qualifications}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2 justify-end">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 w-8 p-0 text-primary border-primary/20 hover:bg-primary/10"
                          onClick={() => handleEdit(doctor)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 w-8 p-0 text-destructive border-destructive/20 hover:bg-destructive/10"
                          onClick={() => handleDelete(doctor.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="text-muted-foreground mb-4">
                <path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"></path>
                <path d="M3 11v5a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v2H7v-2a2 2 0 0 0-4 0Z"></path>
                <path d="M5 18v2"></path>
                <path d="M19 18v2"></path>
              </svg>
              <p className="text-muted-foreground mb-2">No doctors found</p>
              <p className="text-sm text-muted-foreground">Add a new doctor to get started</p>
            </div>
          )}
          
          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <AlertDialogContent className="border-destructive/20">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-destructive">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                  </svg>
                  Are you sure?
                </AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the doctor's record
                  and all associated data from our servers.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="border-muted-foreground/20">Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={confirmDelete}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  disabled={deleteDoctor.isPending}
                >
                  {deleteDoctor.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Deleting...
                    </>
                  ) : (
                    'Delete'
                  )}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </>
      )}
    </div>
  );
}