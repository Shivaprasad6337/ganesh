import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

// Form validation schema
const doctorFormSchema = z.object({
  name: z.string().min(2, { message: "Name is required" }),
  specialty: z.string().min(2, { message: "Specialty is required" }),
  qualifications: z.string().min(2, { message: "Qualifications are required" }),
  bio: z.string().min(10, { message: "Bio must be at least 10 characters" }),
  image_url: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal('')),
});

type DoctorFormValues = z.infer<typeof doctorFormSchema>;

export function AddDoctorForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<DoctorFormValues>({
    resolver: zodResolver(doctorFormSchema),
    defaultValues: {
      name: '',
      specialty: '',
      qualifications: '',
      bio: '',
      image_url: '',
    },
  });
  
  const createDoctor = useMutation({
    mutationFn: async (data: DoctorFormValues) => {
      return apiRequest('POST', '/api/doctors', data);
    },
    onSuccess: () => {
      toast({
        title: 'Doctor added',
        description: 'The doctor has been successfully added to the system.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/doctors'] });
      form.reset();
    },
    onError: (error) => {
      console.error('Error adding doctor:', error);
      toast({
        title: 'Error',
        description: 'There was an error adding the doctor. Please try again.',
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = (values: DoctorFormValues) => {
    // If image_url is empty, set it to a default value or null
    const formData = {
      ...values,
      image_url: values.image_url || null,
    };
    
    createDoctor.mutate(formData);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Dr. John Doe" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="specialty"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Specialty</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Cardiologist" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="qualifications"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Qualifications</FormLabel>
              <FormControl>
                <Input {...field} placeholder="MD, PhD" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="bio"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Bio</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder="Brief description of the doctor's background and expertise"
                  rows={4}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="image_url"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Profile Image URL (Optional)</FormLabel>
              <FormControl>
                <Input {...field} placeholder="https://example.com/doctor-image.jpg" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <Button 
          type="submit" 
          className="w-full"
          disabled={createDoctor.isPending}
        >
          {createDoctor.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
              Adding...
            </>
          ) : (
            'Add Doctor'
          )}
        </Button>
      </form>
    </Form>
  );
}