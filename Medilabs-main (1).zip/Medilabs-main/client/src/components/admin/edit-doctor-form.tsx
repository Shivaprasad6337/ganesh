import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

// Form validation schema
const doctorFormSchema = z.object({
  name: z.string().min(2, { message: "Name is required" }),
  specialty: z.string().min(2, { message: "Specialty is required" }),
  qualifications: z.string().min(2, { message: "Qualifications are required" }),
  bio: z.string().min(10, { message: "Bio must be at least 10 characters" }),
  image_url: z.string().url({ message: "Please enter a valid URL" }).optional().or(z.literal('')),
});

type DoctorFormValues = z.infer<typeof doctorFormSchema>;

interface EditDoctorFormProps {
  doctor: {
    id: number;
    name: string;
    specialty: string;
    qualifications: string;
    bio: string;
    image_url: string;
  };
  onComplete: () => void;
}

export function EditDoctorForm({ doctor, onComplete }: EditDoctorFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<DoctorFormValues>({
    resolver: zodResolver(doctorFormSchema),
    defaultValues: {
      name: doctor.name,
      specialty: doctor.specialty,
      qualifications: doctor.qualifications,
      bio: doctor.bio,
      image_url: doctor.image_url || '',
    },
  });
  
  const updateDoctor = useMutation({
    mutationFn: async (data: DoctorFormValues) => {
      return apiRequest('PUT', `/api/doctors/${doctor.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: 'Doctor updated',
        description: 'The doctor information has been successfully updated.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/doctors'] });
      onComplete();
    },
    onError: (error) => {
      console.error('Error updating doctor:', error);
      toast({
        title: 'Error',
        description: 'There was an error updating the doctor. Please try again.',
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = (values: DoctorFormValues) => {
    // If image_url is empty, set it to a default value or null
    const formData = {
      ...values,
      image_url: values.image_url || null,
    };
    
    updateDoctor.mutate(formData);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Dr. John Doe" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="specialty"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Specialty</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Cardiologist" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="qualifications"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Qualifications</FormLabel>
              <FormControl>
                <Input {...field} placeholder="MD, PhD" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="bio"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Bio</FormLabel>
              <FormControl>
                <Textarea 
                  {...field} 
                  placeholder="Brief description of the doctor's background and expertise"
                  rows={4}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="image_url"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Profile Image URL (Optional)</FormLabel>
              <FormControl>
                <Input {...field} placeholder="https://example.com/doctor-image.jpg" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex justify-end space-x-2">
          <Button 
            type="button" 
            variant="outline"
            onClick={onComplete}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={updateDoctor.isPending}
          >
            {updateDoctor.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                Updating...
              </>
            ) : (
              'Update Doctor'
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}