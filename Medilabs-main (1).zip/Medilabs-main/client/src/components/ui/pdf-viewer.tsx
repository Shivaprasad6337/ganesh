import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, Download, Printer, ChevronLeft, ChevronRight } from "lucide-react";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

interface PdfViewerProps {
  billData: {
    billId: number;
    billDate: string;
    patientName: string;
    patientEmail: string;
    appointmentDate: string;
    appointmentTime: string;
    type: string;
    test: any;
    doctor: any;
    amount: string;
    status: string;
  };
}

export function PdfViewer({ billData }: PdfViewerProps) {
  const [isLoading, setIsLoading] = useState(true);
  const pdfRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Simulate PDF loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  const handleDownload = async () => {
    if (pdfRef.current) {
      const canvas = await html2canvas(pdfRef.current, {
        scale: 2, // Higher scale for better quality
        useCORS: true,
        logging: false,
      });
      
      const imgData = canvas.toDataURL("image/jpeg", 1.0);
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });
      
      const imgWidth = 210; // A4 width in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(imgData, "JPEG", 0, 0, imgWidth, imgHeight);
      pdf.save(`MediLabs_Bill_${billData.billId}.pdf`);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-10">
        <Loader2 className="h-10 w-10 text-primary animate-spin mb-4" />
        <p className="text-gray-600">Preparing your bill...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col">
      <div className="flex justify-between mb-4 print:hidden">
        <Button variant="outline" onClick={handlePrint}>
          <Printer className="h-4 w-4 mr-2" /> Print
        </Button>
        <Button onClick={handleDownload}>
          <Download className="h-4 w-4 mr-2" /> Download PDF
        </Button>
      </div>
      
      <div 
        ref={pdfRef} 
        className="bg-white p-8 rounded-lg shadow-sm border border-gray-200 min-h-[842px] w-full max-w-[595px] mx-auto"
        style={{ fontFamily: "Arial, sans-serif" }}
      >
        {/* Header with Logo */}
        <div className="flex justify-between items-center pb-6 border-b border-gray-200">
          <div className="flex items-center">
            <div className="text-primary-600 text-4xl mr-2">⚕️</div>
            <div>
              <h1 className="text-2xl font-bold text-primary-700">MediLabs</h1>
              <p className="text-sm text-gray-500">Diagnostic Center & Pathology</p>
            </div>
          </div>
          <div className="text-right">
            <h2 className="text-lg font-bold text-gray-800">INVOICE</h2>
            <p className="text-sm text-gray-500">#{billData.billId.toString().padStart(6, '0')}</p>
          </div>
        </div>
        
        {/* Bill Info */}
        <div className="grid grid-cols-2 gap-6 mt-6">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-1">BILL TO</h3>
            <p className="font-medium">{billData.patientName}</p>
            <p className="text-sm text-gray-600">{billData.patientEmail}</p>
          </div>
          <div className="text-right">
            <h3 className="text-sm font-medium text-gray-500 mb-1">BILL DATE</h3>
            <p className="font-medium">{billData.billDate}</p>
            <h3 className="text-sm font-medium text-gray-500 mt-2 mb-1">STATUS</h3>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
              billData.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
            }`}>
              {billData.status === 'completed' ? 'Paid' : 'Payment Pending'}
            </span>
          </div>
        </div>
        
        {/* Appointment Details */}
        <div className="mt-8">
          <h3 className="text-sm font-medium text-gray-500 mb-3">APPOINTMENT DETAILS</h3>
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Date</p>
                <p className="font-medium">{billData.appointmentDate}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Time</p>
                <p className="font-medium">{billData.appointmentTime}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Type</p>
                <p className="font-medium capitalize">{billData.type}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Service</p>
                <p className="font-medium">
                  {billData.type === 'test' ? billData.test?.name : `Consultation with ${billData.doctor?.name}`}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bill Items */}
        <div className="mt-8">
          <h3 className="text-sm font-medium text-gray-500 mb-3">BILL DETAILS</h3>
          <table className="w-full">
            <thead className="bg-gray-50 text-left">
              <tr>
                <th className="py-2 px-4 text-sm font-medium text-gray-500">ITEM</th>
                <th className="py-2 px-4 text-sm font-medium text-gray-500 text-right">AMOUNT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              <tr>
                <td className="py-3 px-4">
                  {billData.type === 'test' 
                    ? billData.test?.name || 'Diagnostic Test'
                    : `Consultation with ${billData.doctor?.name || 'Doctor'}`}
                </td>
                <td className="py-3 px-4 text-right">
                  ${parseFloat(billData.amount) - 5}
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4">Service Fee</td>
                <td className="py-3 px-4 text-right">$5.00</td>
              </tr>
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-gray-200">
                <td className="py-3 px-4 font-bold">Total</td>
                <td className="py-3 px-4 text-right font-bold">${billData.amount}</td>
              </tr>
            </tfoot>
          </table>
        </div>
        
        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-gray-200 text-center">
          <p className="text-sm text-gray-500">
            Thank you for choosing MediLabs for your healthcare needs.
          </p>
          <p className="text-xs text-gray-400 mt-2">
            For any questions regarding this bill, please contact our billing department at billing@medilabs.com
          </p>
        </div>
      </div>
    </div>
  );
}
