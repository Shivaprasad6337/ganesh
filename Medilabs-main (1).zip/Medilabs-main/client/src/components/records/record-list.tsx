import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Download, Eye, File, FileText, RefreshCw, AlertCircle } from 'lucide-react';
import { FaVial } from 'react-icons/fa';

interface TestResult {
  id: number;
  appointment_id: number;
  result_status: 'normal' | 'abnormal' | 'inconclusive';
  details: string;
  pdf_url: string | null;
  created_at: string;
  appointment_date: string;
  test_name: string;
}

export function RecordList() {
  const [activeTab, setActiveTab] = useState('test-results');
  const [selectedResult, setSelectedResult] = useState<TestResult | null>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);

  const { data: results, isLoading, error, refetch } = useQuery<TestResult[]>({
    queryKey: ['/api/results'],
  });

  // Format date
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy');
    } catch (error) {
      return dateString;
    }
  };

  // Get result status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'normal':
        return 'bg-green-100 text-green-800';
      case 'abnormal':
        return 'bg-red-100 text-red-800';
      case 'inconclusive':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Handle view details
  const handleViewDetails = (result: TestResult) => {
    setSelectedResult(result);
    setShowDetailsDialog(true);
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64 mb-4" />
        <div className="bg-white rounded-lg shadow-sm">
          <Skeleton className="h-14 w-full" />
        </div>
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-40 w-full" />
        ))}
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="text-center py-10">
        <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium">Error Loading Medical Records</h3>
        <p className="text-gray-500 mt-2">Could not load your medical records. Please try again later.</p>
        <Button onClick={() => refetch()} className="mt-4">
          <RefreshCw className="mr-2 h-4 w-4" /> Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter Tabs */}
      <Tabs defaultValue="test-results" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white rounded-lg shadow-sm w-full justify-start">
          <TabsTrigger value="test-results">Test Results</TabsTrigger>
          <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
          <TabsTrigger value="medical-history">Medical History</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Content based on active tab */}
      <TabsContent value="test-results" className="mt-0">
        <div className="space-y-6">
          {results && results.length > 0 ? (
            results.map(result => (
              <Card key={result.id} className="border border-gray-200">
                <CardContent className="p-6">
                  <div className="flex flex-col sm:flex-row justify-between items-start">
                    <div>
                      <div className="flex items-center mb-2">
                        <h3 className="text-lg font-medium text-gray-800">{result.test_name}</h3>
                        <span className={`ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeClass(result.result_status)}`}>
                          {result.result_status.charAt(0).toUpperCase() + result.result_status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">
                        <FileText className="inline mr-1.5 h-4 w-4 text-gray-500" />
                        {formatDate(result.appointment_date)}
                      </p>
                    </div>
                    <div className="mt-3 sm:mt-0">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="mr-2"
                        onClick={() => {
                          // Download functionality would be implemented here
                          // For now, we'll just alert
                          alert('Download functionality will be implemented here');
                        }}
                      >
                        <Download className="mr-1.5 h-4 w-4" /> Download
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => handleViewDetails(result)}
                      >
                        <Eye className="mr-1.5 h-4 w-4" /> View Details
                      </Button>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h4 className="text-sm font-medium text-gray-800 mb-2">Test Results Summary</h4>
                    <div className="text-sm text-gray-600">
                      {result.details ? (
                        <p>{result.details}</p>
                      ) : (
                        <p className="italic text-gray-500">No detailed description available</p>
                      )}
                    </div>
                    {result.result_status !== 'normal' && (
                      <div className="mt-3">
                        <h4 className="text-sm font-medium text-primary-700 mb-1">Suggested Follow-up</h4>
                        <p className="text-sm text-gray-600">Based on your results, we recommend the following:</p>
                        <ul className="mt-1 list-disc pl-5 text-sm text-gray-600">
                          {result.test_name.toLowerCase().includes('lipid') && (
                            <li>Consider a cardiology consultation for a comprehensive heart health assessment.</li>
                          )}
                          {result.test_name.toLowerCase().includes('blood count') && (
                            <li>Repeat test in 3 months to monitor progress.</li>
                          )}
                          {result.test_name.toLowerCase().includes('glucose') && (
                            <li>Schedule a follow-up with an endocrinologist.</li>
                          )}
                          {result.result_status === 'inconclusive' && (
                            <li>Repeat the test within 2 weeks for confirmation.</li>
                          )}
                        </ul>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-blue-100">
                  <FaVial className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No test results found</h3>
                <p className="mt-1 text-sm text-gray-500">You don't have any test results yet.</p>
                <div className="mt-6">
                  <Button
                    onClick={() => window.location.href = '/tests'}
                  >
                    Book Your First Test
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </TabsContent>
      
      <TabsContent value="prescriptions" className="mt-0">
        <Card>
          <CardContent className="p-8 text-center">
            <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-blue-100">
              <File className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No prescriptions found</h3>
            <p className="mt-1 text-sm text-gray-500">You don't have any prescriptions yet.</p>
          </CardContent>
        </Card>
      </TabsContent>
      
      <TabsContent value="medical-history" className="mt-0">
        <Card>
          <CardContent className="p-8 text-center">
            <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-blue-100">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No medical history records</h3>
            <p className="mt-1 text-sm text-gray-500">
              Your medical history will appear here after you have completed appointments or tests.
            </p>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Result Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Test Result Details</DialogTitle>
            <DialogDescription>
              Detailed information about your test result
            </DialogDescription>
          </DialogHeader>
          
          {selectedResult && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-md">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Test Name</p>
                    <p className="font-medium">{selectedResult.test_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Date</p>
                    <p className="font-medium">{formatDate(selectedResult.appointment_date)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeClass(selectedResult.result_status)}`}>
                      {selectedResult.result_status.charAt(0).toUpperCase() + selectedResult.result_status.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-800 mb-2">Result Details</h3>
                <div className="bg-white border border-gray-200 rounded-md p-4">
                  <pre className="text-sm text-gray-600 whitespace-pre-wrap font-sans">
                    {selectedResult.details || "No detailed description available"}
                  </pre>
                </div>
              </div>
              
              {selectedResult.result_status !== 'normal' && (
                <div>
                  <h3 className="text-sm font-medium text-primary-700 mb-2">Recommendations</h3>
                  <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                    <p className="text-sm text-gray-700">Based on your results, we recommend:</p>
                    <ul className="mt-2 list-disc pl-5 text-sm text-gray-700 space-y-1">
                      {selectedResult.test_name.toLowerCase().includes('lipid') && (
                        <>
                          <li>Schedule a follow-up appointment with a cardiologist</li>
                          <li>Maintain a heart-healthy diet low in saturated fats</li>
                          <li>Exercise regularly, aiming for at least 150 minutes per week</li>
                        </>
                      )}
                      {selectedResult.test_name.toLowerCase().includes('blood count') && (
                        <>
                          <li>Repeat test in 3 months to monitor progress</li>
                          <li>Ensure adequate iron intake in your diet</li>
                          <li>Stay hydrated by drinking plenty of water</li>
                        </>
                      )}
                      {selectedResult.test_name.toLowerCase().includes('glucose') && (
                        <>
                          <li>Schedule a follow-up with an endocrinologist</li>
                          <li>Monitor your carbohydrate intake</li>
                          <li>Maintain regular physical activity</li>
                        </>
                      )}
                      {selectedResult.result_status === 'inconclusive' && (
                        <li>Repeat the test within 2 weeks for confirmation</li>
                      )}
                    </ul>
                  </div>
                </div>
              )}
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowDetailsDialog(false)}>
                  Close
                </Button>
                <Button>
                  <Download className="mr-1.5 h-4 w-4" /> Download Report
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
