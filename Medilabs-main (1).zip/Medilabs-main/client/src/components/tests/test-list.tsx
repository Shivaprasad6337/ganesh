import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { TestCard } from './test-card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Search } from 'lucide-react';

interface Test {
  id: number;
  name: string;
  description: string;
  price: string;
  category: string;
  popular: boolean;
}

export function TestList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [priceFilter, setPriceFilter] = useState('any');

  const { data: tests, isLoading, error } = useQuery<Test[]>({
    queryKey: ['/api/tests'],
  });

  // Extract unique categories from tests
  const categories = tests ? 
    ['all', ...new Set(tests.map(test => test.category))]
    : ['all'];

  // Filter tests based on search term and filters
  const filteredTests = tests?.filter(test => {
    // Search filter
    const matchesSearch = test.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       test.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Category filter
    const matchesCategory = categoryFilter === 'all' || test.category === categoryFilter;
    
    // Price filter
    let matchesPrice = true;
    const price = parseFloat(test.price);
    
    if (priceFilter === 'under50') {
      matchesPrice = price < 50;
    } else if (priceFilter === '50to100') {
      matchesPrice = price >= 50 && price <= 100;
    } else if (priceFilter === '100to200') {
      matchesPrice = price > 100 && price <= 200;
    } else if (priceFilter === '200plus') {
      matchesPrice = price > 200;
    }
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  // Loading skeleton
  if (isLoading) {
    return (
      <div>
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-grow">
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="sm:w-48">
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="sm:w-48">
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
              <Skeleton className="h-6 w-3/4 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-2/3 mb-4" />
              <div className="flex justify-between items-center">
                <Skeleton className="h-5 w-16" />
                <Skeleton className="h-9 w-24" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return <div className="text-center py-10 text-red-500">Error loading tests. Please try again later.</div>;
  }

  return (
    <div>
      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <Input
              type="text"
              className="pl-10"
              placeholder="Search for tests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="sm:w-48">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.filter(cat => cat !== 'all').map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="sm:w-48">
            <Select value={priceFilter} onValueChange={setPriceFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Price: Any" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Price: Any</SelectItem>
                <SelectItem value="under50">Under $50</SelectItem>
                <SelectItem value="50to100">$50 - $100</SelectItem>
                <SelectItem value="100to200">$100 - $200</SelectItem>
                <SelectItem value="200plus">$200+</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Test List */}
      {filteredTests && filteredTests.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTests.map(test => (
            <TestCard key={test.id} test={test} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-gray-500">No tests found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}
