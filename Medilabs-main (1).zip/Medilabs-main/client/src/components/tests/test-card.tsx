import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { BookingModal } from '@/components/booking/booking-modal';

interface Test {
  id: number;
  name: string;
  description: string;
  price: string;
  category: string;
  popular: boolean;
}

interface TestCardProps {
  test: Test;
}

export function TestCard({ test }: TestCardProps) {
  const [showBookingModal, setShowBookingModal] = useState(false);

  return (
    <>
      <Card className="overflow-hidden border border-gray-200">
        <div className="p-6">
          <div className="flex justify-between items-start">
            <h3 className="font-medium text-gray-800 text-lg">{test.name}</h3>
            {test.popular && (
              <Badge variant="secondary" className="bg-primary-100 text-primary-800 hover:bg-primary-100">
                Popular
              </Badge>
            )}
          </div>
          <p className="mt-2 text-sm text-gray-600">{test.description}</p>
          <div className="mt-4 flex justify-between items-center">
            <span className="text-primary-600 font-medium">${parseFloat(test.price).toFixed(2)}</span>
            <Button 
              onClick={() => setShowBookingModal(true)}
              size="sm"
            >
              Book Now
            </Button>
          </div>
        </div>
      </Card>

      {showBookingModal && (
        <BookingModal
          type="test"
          test={test}
          doctor={null}
          open={showBookingModal}
          onClose={() => setShowBookingModal(false)}
        />
      )}
    </>
  );
}
