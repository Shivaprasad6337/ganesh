import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2 } from "lucide-react";

// Form validation schema
const bookingSchema = z.object({
  patientName: z.string().min(2, { message: "Patient name is required" }),
  date: z.string().min(1, { message: "Date is required" }),
  time: z.string().min(1, { message: "Time is required" }),
  notes: z.string().optional(),
  paymentMethod: z.enum(["pay_now", "pay_later"]),
  additionalTests: z.array(z.number()).optional(),
  homeCollection: z.boolean().default(false),
  address: z.string().optional()
    .refine(val => {
      // Address is required only if home collection is selected
      const formData = bookingSchema?._cached;
      return !formData?.homeCollection || (formData?.homeCollection && val && val.length > 0);
    }, { message: "Address is required for home collection" }),
});

type BookingFormValues = z.infer<typeof bookingSchema>;

interface Test {
  id: number;
  name: string;
  description: string;
  price: string;
  category: string;
  popular: boolean;
}

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  qualifications: string;
  bio: string;
  image_url: string;
  schedules?: Array<{
    id: number;
    doctor_id: number;
    day: string;
    start_time: string;
    end_time: string;
  }>;
}

interface BookingModalProps {
  type: 'test' | 'consultation';
  test: Test | null;
  doctor: Doctor | null;
  open: boolean;
  onClose: () => void;
}

export function BookingModal({ type, test, doctor, open, onClose }: BookingModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [suggestedTests, setSuggestedTests] = useState<Test[]>([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
  
  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      patientName: user?.name || '',
      date: format(new Date(), 'yyyy-MM-dd'),
      time: '',
      notes: '',
      paymentMethod: 'pay_later',
      additionalTests: [],
      homeCollection: false,
      address: '',
    },
  });

  // Generate time slots
  const generateTimeSlots = () => {
    const slots = [];
    let hour = 9;
    let minute = 0;
    
    while (hour < 17) {
      slots.push(`${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`);
      minute += 30;
      if (minute === 60) {
        minute = 0;
        hour += 1;
      }
    }
    
    return slots;
  };
  
  const timeSlots = generateTimeSlots();

  // Fetch test suggestions if booking a test
  useEffect(() => {
    if (type === 'test' && test?.id) {
      setIsLoadingSuggestions(true);
      
      // Fetch suggested tests
      apiRequest('GET', `/api/tests/${test.id}/suggestions`, undefined)
        .then(res => res.json())
        .then(data => {
          setSuggestedTests(data);
        })
        .catch(error => {
          console.error('Error fetching test suggestions:', error);
        })
        .finally(() => {
          setIsLoadingSuggestions(false);
        });
    }
  }, [type, test]);

  // Create booking mutation
  const createBooking = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('POST', '/api/appointments', data);
    },
    onSuccess: () => {
      toast({
        title: 'Booking successful',
        description: 'Your appointment has been scheduled successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      onClose();
      setLocation('/appointments');
    },
    onError: (error) => {
      console.error('Booking error:', error);
      toast({
        title: 'Booking failed',
        description: 'There was an error scheduling your appointment. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Handle form submission
  const onSubmit = async (values: BookingFormValues) => {
    if (!user?.id) {
      toast({
        title: 'Authentication required',
        description: 'Please log in to book an appointment.',
        variant: 'destructive',
      });
      return;
    }

    // Create booking data
    const bookingData = {
      user_id: user.id,
      appointment_date: values.date,
      appointment_time: values.time,
      notes: values.notes,
      type: type,
      [type === 'test' ? 'test_id' : 'doctor_id']: type === 'test' ? test?.id : doctor?.id,
      payment_method: values.paymentMethod,
      additional_tests: values.additionalTests,
      // Add home collection data for test bookings
      home_collection: type === 'test' ? values.homeCollection : false,
      address: type === 'test' && values.homeCollection ? values.address : null,
    };

    createBooking.mutate(bookingData);
  };

  // Calculate total amount
  const calculateTotal = () => {
    let total = 0;
    
    if (type === 'test' && test) {
      total += parseFloat(test.price);
      
      // Add cost of additional tests
      form.watch('additionalTests')?.forEach(testId => {
        const addTest = suggestedTests.find(t => t.id === testId);
        if (addTest) {
          total += parseFloat(addTest.price);
        }
      });
    } else if (type === 'consultation') {
      // Default consultation fee
      total = 120.00;
    }
    
    // Add service fee
    total += 5.00;
    
    return total.toFixed(2);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {type === 'test' 
              ? `Book ${test?.name}` 
              : `Book Consultation with ${doctor?.name}`}
          </DialogTitle>
          <DialogDescription>
            Fill in the details below to schedule your appointment.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="patientName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Patient Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter full name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Select Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} min={format(new Date(), 'yyyy-MM-dd')} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="time"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Select Time</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a time slot" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {timeSlots.map(slot => (
                        <SelectItem key={slot} value={slot}>
                          {slot}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Instructions (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Any additional information we should know"
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Home Sample Collection for Tests Only */}
            {type === 'test' && (
              <>
                <FormField
                  control={form.control}
                  name="homeCollection"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Home Sample Collection</FormLabel>
                        <p className="text-sm text-muted-foreground">
                          Our phlebotomist will visit your home to collect the sample
                        </p>
                      </div>
                    </FormItem>
                  )}
                />
                
                {form.watch('homeCollection') && (
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Home Address</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Enter your complete address for sample collection"
                            rows={3}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </>
            )}

            {/* Suggested Additional Tests */}
            {type === 'test' && suggestedTests.length > 0 && (
              <div className="bg-blue-50 p-3 rounded-md">
                <h4 className="text-sm font-medium text-blue-800 mb-2">Recommended Additional Tests</h4>
                <div className="space-y-2">
                  {suggestedTests.map(suggestedTest => (
                    <FormField
                      key={suggestedTest.id}
                      control={form.control}
                      name="additionalTests"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(suggestedTest.id)}
                              onCheckedChange={(checked) => {
                                return checked
                                  ? field.onChange([...(field.value || []), suggestedTest.id])
                                  : field.onChange(
                                      field.value?.filter(
                                        (value) => value !== suggestedTest.id
                                      )
                                    );
                              }}
                            />
                          </FormControl>
                          <FormLabel className="text-sm font-medium text-gray-700 cursor-pointer">
                            {suggestedTest.name} <span className="text-gray-500">(${parseFloat(suggestedTest.price).toFixed(2)})</span>
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Payment Method */}
            <FormField
              control={form.control}
              name="paymentMethod"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Method</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="space-y-2"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="pay_now" />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Pay Now (Credit/Debit Card)
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0">
                        <FormControl>
                          <RadioGroupItem value="pay_later" />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Pay at the Center
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Total Amount */}
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="flex justify-between">
                <span className="text-sm font-medium text-gray-700">
                  {type === 'test' ? 'Test Charge:' : 'Consultation Fee:'}
                </span>
                <span className="text-sm text-gray-900">
                  ${type === 'test' ? parseFloat(test?.price || '0').toFixed(2) : '120.00'}
                </span>
              </div>
              
              {form.watch('additionalTests')?.length > 0 && (
                <>
                  {form.watch('additionalTests').map(testId => {
                    const addTest = suggestedTests.find(t => t.id === testId);
                    return (
                      <div key={testId} className="flex justify-between mt-1">
                        <span className="text-sm font-medium text-gray-700">
                          {addTest?.name}:
                        </span>
                        <span className="text-sm text-gray-900">
                          ${parseFloat(addTest?.price || '0').toFixed(2)}
                        </span>
                      </div>
                    );
                  })}
                </>
              )}
              
              <div className="flex justify-between mt-1">
                <span className="text-sm font-medium text-gray-700">Service Fee:</span>
                <span className="text-sm text-gray-900">$5.00</span>
              </div>
              
              <div className="flex justify-between mt-2 pt-2 border-t border-gray-200">
                <span className="font-medium">Total:</span>
                <span className="font-medium">${calculateTotal()}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createBooking.isPending}
              >
                {createBooking.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                    Processing
                  </>
                ) : (
                  'Confirm Booking'
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
