import { Link } from "wouter";
import { FlaskRound } from "lucide-react";
import { FaFacebookF, FaInstagram, FaTwitter, FaLinkedinIn } from "react-icons/fa";

export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 mt-8">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex items-center">
            <FlaskRound className="h-6 w-6 text-primary mr-2" />
            <span className="text-xl font-bold text-primary-700">MediLabs</span>
          </div>
          
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-base text-gray-500">
              &copy; {new Date().getFullYear()} MediLabs. All rights reserved.
            </p>
          </div>
          
          <div className="flex justify-center space-x-6 md:order-2 mt-6 md:mt-0">
            <a
              href="#"
              className="text-gray-400 hover:text-gray-500"
              aria-label="Facebook"
            >
              <FaFacebookF className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-gray-500"
              aria-label="Instagram"
            >
              <FaInstagram className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-gray-500"
              aria-label="Twitter"
            >
              <FaTwitter className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-gray-500"
              aria-label="LinkedIn"
            >
              <FaLinkedinIn className="h-5 w-5" />
            </a>
          </div>
        </div>
        
        <div className="mt-4 flex justify-center space-x-6">
          <Link href="/privacy" className="text-sm text-gray-500 hover:text-gray-900">
            Privacy Policy
          </Link>
          <Link href="/terms" className="text-sm text-gray-500 hover:text-gray-900">
            Terms of Service
          </Link>
          <Link href="/contact" className="text-sm text-gray-500 hover:text-gray-900">
            Contact Us
          </Link>
        </div>
      </div>
    </footer>
  );
}
