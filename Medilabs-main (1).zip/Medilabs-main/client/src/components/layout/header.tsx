import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { FlaskRound, UserCircle, Menu, X } from "lucide-react";

export function Header() {
  const { isAuthenticated, user, logout } = useAuth();
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: "Home", href: "/dashboard", active: location === "/dashboard" },
    { name: "Tests", href: "/tests", active: location === "/tests" },
    { name: "Doctors", href: "/doctors", active: location === "/doctors" },
    { name: "My Appointments", href: "/appointments", active: location === "/appointments" },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href={isAuthenticated ? "/dashboard" : "/"} className="flex items-center">
                <FlaskRound className="h-6 w-6 text-primary mr-2" />
                <span className="text-xl font-bold text-primary-700">MediLabs</span>
              </Link>
            </div>
            
            {isAuthenticated && (
              <nav className="hidden sm:ml-6 sm:flex sm:space-x-8">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`${
                      item.active
                        ? "border-primary-500 text-primary-700"
                        : "border-transparent text-gray-500 hover:border-primary-300 hover:text-primary-700"
                    } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-full`}
                  >
                    {item.name}
                  </Link>
                ))}
              </nav>
            )}
          </div>
          
          {isAuthenticated ? (
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative rounded-full h-8 w-8 flex items-center justify-center">
                    <span className="sr-only">Open user menu</span>
                    <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary-700 uppercase font-semibold">
                      {user?.name?.[0] || "U"}
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-4 py-2">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-gray-500">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/records" className="w-full cursor-pointer">
                      Medical Records
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile" className="w-full cursor-pointer">
                      Profile Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={logout}
                    className="text-red-600 cursor-pointer"
                  >
                    Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <div className="hidden sm:flex sm:items-center sm:space-x-4">
              <Link href="/login">
                <Button variant="ghost">Login</Button>
              </Link>
              <Link href="/register">
                <Button>Register</Button>
              </Link>
            </div>
          )}
          
          {/* Mobile menu button */}
          <div className="flex items-center sm:hidden">
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <span className="sr-only">Open menu</span>
                  {isMenuOpen ? (
                    <X className="h-6 w-6" />
                  ) : (
                    <Menu className="h-6 w-6" />
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="sm:hidden">
                <div className="flex flex-col h-full pt-6">
                  <div className="flex items-center mb-6">
                    <FlaskRound className="h-6 w-6 text-primary mr-2" />
                    <span className="text-xl font-bold text-primary-700">MediLabs</span>
                  </div>
                  
                  {isAuthenticated ? (
                    <>
                      <div className="flex items-center border-b border-gray-200 pb-4 mb-4">
                        <UserCircle className="h-10 w-10 text-primary mr-3" />
                        <div>
                          <p className="font-medium">{user?.name}</p>
                          <p className="text-sm text-gray-500">{user?.email}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        {navigation.map((item) => (
                          <Link
                            key={item.name}
                            href={item.href}
                            className={`${
                              item.active
                                ? "bg-primary-50 text-primary-700 border-l-4 border-primary-500"
                                : "text-gray-600 border-l-4 border-transparent"
                            } block pl-3 pr-4 py-2 text-base font-medium`}
                            onClick={() => setIsMenuOpen(false)}
                          >
                            {item.name}
                          </Link>
                        ))}
                        <Link
                          href="/records"
                          className={`${
                            location === "/records"
                              ? "bg-primary-50 text-primary-700 border-l-4 border-primary-500"
                              : "text-gray-600 border-l-4 border-transparent"
                          } block pl-3 pr-4 py-2 text-base font-medium`}
                          onClick={() => setIsMenuOpen(false)}
                        >
                          Medical Records
                        </Link>
                      </div>
                      
                      <div className="mt-auto border-t border-gray-200 pt-4">
                        <button
                          className="block w-full text-left pl-3 pr-4 py-2 text-base font-medium text-red-600"
                          onClick={() => {
                            logout();
                            setIsMenuOpen(false);
                          }}
                        >
                          Sign out
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col space-y-4 pt-4">
                      <Link href="/login" onClick={() => setIsMenuOpen(false)}>
                        <Button variant="ghost" className="w-full justify-start">
                          Login
                        </Button>
                      </Link>
                      <Link href="/register" onClick={() => setIsMenuOpen(false)}>
                        <Button className="w-full">Register</Button>
                      </Link>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
