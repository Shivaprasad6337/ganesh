import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { apiRequest } from '@/lib/queryClient';
import { PdfViewer } from '@/components/ui/pdf-viewer';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from '@/hooks/use-toast';
import { Calendar, Clock, FileText, XCircle, RefreshCw } from 'lucide-react';

interface Appointment {
  id: number;
  type: 'test' | 'consultation';
  appointment_date: string;
  appointment_time: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes: string;
  test_id: number | null;
  test_name?: string;
  test_price?: string;
  doctor_id: number | null;
  doctor_name?: string;
  doctor_specialty?: string;
  payment: {
    id?: number;
    status: 'pending' | 'completed';
    amount?: string;
  };
}

export function AppointmentList() {
  const [activeTab, setActiveTab] = useState('upcoming');
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [showBillDialog, setShowBillDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [billData, setBillData] = useState<any | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch appointments
  const { data: appointments, isLoading, error } = useQuery<Appointment[]>({
    queryKey: ['/api/appointments'],
  });

  // Fetch bill data
  const fetchBill = async (appointmentId: number) => {
    try {
      const response = await apiRequest('GET', `/api/bills/${appointmentId}/pdf`, undefined);
      const data = await response.json();
      setBillData(data);
      setShowBillDialog(true);
    } catch (error) {
      console.error('Error fetching bill:', error);
      toast({
        title: 'Error',
        description: 'Could not load bill details.',
        variant: 'destructive',
      });
    }
  };

  // Cancel appointment mutation
  const cancelAppointmentMutation = useMutation({
    mutationFn: async (appointmentId: number) => {
      return apiRequest('PUT', `/api/appointments/${appointmentId}/status`, { status: 'cancelled' });
    },
    onSuccess: () => {
      toast({
        title: 'Appointment Cancelled',
        description: 'Your appointment has been cancelled successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
      setShowCancelDialog(false);
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Could not cancel appointment. Please try again.',
        variant: 'destructive',
      });
    }
  });

  // Handle cancel appointment
  const handleCancelAppointment = () => {
    if (selectedAppointment) {
      cancelAppointmentMutation.mutate(selectedAppointment.id);
    }
  };

  // Filter appointments based on tab
  const filterAppointments = (appointments: Appointment[] = []) => {
    switch (activeTab) {
      case 'upcoming':
        return appointments.filter(
          app => app.status !== 'completed' && app.status !== 'cancelled'
        );
      case 'past':
        return appointments.filter(app => app.status === 'completed');
      case 'cancelled':
        return appointments.filter(app => app.status === 'cancelled');
      default:
        return appointments;
    }
  };

  const filteredAppointments = filterAppointments(appointments);

  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy');
    } catch (error) {
      return dateString;
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64 mb-4" />
        <div className="bg-white rounded-lg shadow-sm">
          <Skeleton className="h-14 w-full" />
        </div>
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-40 w-full" />
        ))}
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="text-center py-10">
        <XCircle className="h-10 w-10 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium">Error Loading Appointments</h3>
        <p className="text-gray-500 mt-2">Could not load your appointments. Please try again later.</p>
        <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/appointments'] })} className="mt-4">
          <RefreshCw className="mr-2 h-4 w-4" /> Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter Tabs */}
      <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white rounded-lg shadow-sm w-full justify-start">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Appointment List */}
      <div className="space-y-4">
        {filteredAppointments && filteredAppointments.length > 0 ? (
          filteredAppointments.map(appointment => (
            <Card key={appointment.id} className="border border-gray-200">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between">
                  <div className="mb-4 md:mb-0">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mb-2 
                      ${appointment.type === 'test' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}
                    >
                      {appointment.type === 'test' ? 'Diagnostic Test' : 'Consultation'}
                    </span>
                    <h3 className="text-lg font-medium text-gray-800">
                      {appointment.type === 'test' ? appointment.test_name : appointment.doctor_name}
                    </h3>
                    {appointment.type === 'consultation' && appointment.doctor_specialty && (
                      <p className="text-sm text-primary-600 mt-1">{appointment.doctor_specialty}</p>
                    )}
                    <div className="mt-2 flex items-center text-sm text-gray-600">
                      <Calendar className="mr-2 h-4 w-4 text-gray-500" />
                      <span>{formatDate(appointment.appointment_date)}</span>
                    </div>
                    <div className="mt-1 flex items-center text-sm text-gray-600">
                      <Clock className="mr-2 h-4 w-4 text-gray-500" />
                      <span>{appointment.appointment_time}</span>
                    </div>
                  </div>
                  
                  <div className="flex flex-col md:items-end">
                    <div className="mb-2 flex items-center">
                      <span className="text-sm font-medium mr-2">Status:</span>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${appointment.status === 'completed' ? 'bg-green-100 text-green-800' : ''}
                        ${appointment.status === 'confirmed' ? 'bg-blue-100 text-blue-800' : ''}
                        ${appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-800' : ''}
                        ${appointment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                        ${appointment.status === 'cancelled' ? 'bg-red-100 text-red-800' : ''}
                      `}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </div>
                    
                    <div className="mb-4 flex items-center">
                      <span className="text-sm font-medium mr-2">Payment:</span>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${appointment.payment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                      `}>
                        {appointment.payment.status === 'completed' ? 'Paid' : 'Pending'}
                      </span>
                    </div>
                    
                    <div className="flex space-x-3 mt-2">
                      {appointment.status !== 'completed' && appointment.status !== 'cancelled' && (
                        <>
                          <Button variant="outline" size="sm">
                            Reschedule
                          </Button>
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => {
                              setSelectedAppointment(appointment);
                              setShowCancelDialog(true);
                            }}
                          >
                            Cancel
                          </Button>
                        </>
                      )}
                      
                      {appointment.status === 'completed' && (
                        <Button
                          size="sm"
                          onClick={() => fetchBill(appointment.id)}
                        >
                          <FileText className="mr-1.5 h-4 w-4" /> View Report
                        </Button>
                      )}
                      
                      {appointment.payment.status === 'pending' && (
                        <Button size="sm">
                          Pay Now
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
                
                {appointment.payment.status === 'pending' && appointment.payment.amount && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
                      <div className="mb-3 sm:mb-0">
                        <span className="font-medium text-gray-800">Amount Due: </span>
                        <span className="font-medium text-primary-700">
                          ${parseFloat(appointment.payment.amount).toFixed(2)}
                        </span>
                      </div>
                      <Button>
                        Pay Now
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-blue-100">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="mt-2 text-sm font-medium text-gray-900">
                No {activeTab} appointments
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                {activeTab === 'upcoming' 
                  ? "You don't have any upcoming appointments scheduled." 
                  : activeTab === 'past'
                    ? "You don't have any past appointments."
                    : "You don't have any cancelled appointments."}
              </p>
              {activeTab === 'upcoming' && (
                <div className="mt-6">
                  <Button
                    onClick={() => window.location.href = '/tests'}
                  >
                    Book a Test
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Bill Dialog */}
      <Dialog open={showBillDialog} onOpenChange={setShowBillDialog}>
        <DialogContent className="max-w-3xl h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Bill Details</DialogTitle>
            <DialogDescription>
              View or download your bill
            </DialogDescription>
          </DialogHeader>
          {billData && <PdfViewer billData={billData} />}
        </DialogContent>
      </Dialog>

      {/* Cancel Appointment Confirmation */}
      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Appointment</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel this appointment? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Appointment</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleCancelAppointment}
              className="bg-red-600 hover:bg-red-700"
            >
              Cancel Appointment
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
