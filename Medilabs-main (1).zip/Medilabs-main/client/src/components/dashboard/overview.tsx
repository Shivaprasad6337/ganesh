import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { 
  FlaskRound, 
  UserRound, 
  FileText, 
  CalendarCheck 
} from "lucide-react";

interface Appointment {
  id: number;
  type: string;
  test_name?: string;
  doctor_name?: string;
  appointment_date: string;
  appointment_time: string;
  status: string;
  payment: {
    status: string;
  };
}

interface TestResult {
  id: number;
  test_name: string;
  appointment_date: string;
  result_status: string;
  details: string;
}

export function DashboardOverview() {
  const { user } = useAuth();

  const { data: appointments, isLoading: isLoadingAppointments } = useQuery({
    queryKey: ["/api/appointments"],
    enabled: !!user
  });

  const { data: results, isLoading: isLoadingResults } = useQuery({
    queryKey: ["/api/results"],
    enabled: !!user
  });

  // Get only upcoming appointments (not completed or cancelled)
  const upcomingAppointments = appointments?.filter(
    (appointment: Appointment) => appointment.status !== "completed" && appointment.status !== "cancelled"
  ).slice(0, 2) || [];

  // Get recent test results
  const recentResults = results?.slice(0, 2) || [];

  const featuredPackages = [
    {
      id: 1,
      name: "Comprehensive Health Package",
      description: "Complete evaluation including CBC, metabolic panel, thyroid tests and more",
      price: "$199.99",
      image: "https://images.unsplash.com/photo-1581594549595-35f6edc7b762?auto=format&fit=crop&w=800&h=450&q=80"
    },
    {
      id: 2,
      name: "Diabetes Screening",
      description: "Includes fasting glucose, HbA1c, and complete diabetes risk assessment",
      price: "$89.99",
      image: "https://pixabay.com/get/g57ca6c0d254c0cc3438c89866d7680cff03ae6b4a153129689e96ee7b4bc328d08c2da67c6b41cdd6b1de4ae4d92a920ca59418aab8c75f21e15476357c43ad7_1280.jpg"
    },
    {
      id: 3,
      name: "Heart Health Package",
      description: "Comprehensive heart assessment including ECG, lipid panel, and cardiac markers",
      price: "$149.99",
      image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&h=450&q=80"
    }
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Welcome back, {user?.name || "User"}</h1>
        <p className="mt-1 text-sm text-gray-600">Here's an overview of your health dashboard</p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Upcoming Appointments */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-800">Upcoming Appointments</h2>
              <Link href="/appointments">
                <Button variant="link" className="text-primary">View all</Button>
              </Link>
            </div>
            
            <div className="space-y-4">
              {isLoadingAppointments ? (
                <>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                </>
              ) : upcomingAppointments.length > 0 ? (
                upcomingAppointments.map((appointment: Appointment) => (
                  <div key={appointment.id} className="border border-gray-200 rounded-md p-4">
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium text-gray-800">
                          {appointment.type === 'test' ? appointment.test_name : appointment.doctor_name}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          {new Date(appointment.appointment_date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })} at {appointment.appointment_time}
                        </p>
                      </div>
                      <div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                          ${appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' : ''}
                          ${appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-800' : ''}
                          ${appointment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : ''}
                        `}>
                          {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                        </span>
                        <span className={`block mt-1 text-xs font-medium
                          ${appointment.payment.status === 'paid' ? 'text-green-600' : ''}
                          ${appointment.payment.status === 'pending' ? 'text-yellow-600' : ''}
                        `}>
                          {appointment.payment.status === 'completed' ? 'Paid' : 'Payment Pending'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500">No upcoming appointments</p>
                  <Link href="/tests">
                    <Button className="mt-2">Book a Test</Button>
                  </Link>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Test Results */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-medium text-gray-800">Recent Test Results</h2>
              <Link href="/records">
                <Button variant="link" className="text-primary">View all</Button>
              </Link>
            </div>
            
            <div className="space-y-4">
              {isLoadingResults ? (
                <>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                </>
              ) : recentResults.length > 0 ? (
                recentResults.map((result: TestResult) => (
                  <div key={result.id} className="border border-gray-200 rounded-md p-4">
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium text-gray-800">{result.test_name}</p>
                        <p className="text-sm text-gray-600 mt-1">
                          {new Date(result.appointment_date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })}
                        </p>
                      </div>
                      <div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                          ${result.result_status === 'normal' ? 'bg-green-100 text-green-800' : ''}
                          ${result.result_status === 'abnormal' ? 'bg-red-100 text-red-800' : ''}
                          ${result.result_status === 'inconclusive' ? 'bg-yellow-100 text-yellow-800' : ''}
                        `}>
                          {result.result_status.charAt(0).toUpperCase() + result.result_status.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <p className="text-gray-500">No test results available</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Access */}
      <div>
        <h2 className="text-xl font-medium text-gray-800 mb-4">Quick Access</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link href="/tests">
            <Card className="hover:shadow transition cursor-pointer h-full">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <FlaskRound className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-gray-800">Book a Test</h3>
                  <p className="mt-1 text-sm text-gray-500">Schedule diagnostic tests</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/doctors">
            <Card className="hover:shadow transition cursor-pointer h-full">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <UserRound className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-gray-800">Book a Consultation</h3>
                  <p className="mt-1 text-sm text-gray-500">Connect with our specialists</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/records">
            <Card className="hover:shadow transition cursor-pointer h-full">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <FileText className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-gray-800">Medical Records</h3>
                  <p className="mt-1 text-sm text-gray-500">View your health history</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/appointments">
            <Card className="hover:shadow transition cursor-pointer h-full">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <CalendarCheck className="h-8 w-8 text-primary mb-3" />
                  <h3 className="font-medium text-gray-800">Appointments</h3>
                  <p className="mt-1 text-sm text-gray-500">Manage your appointments</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* Featured Health Packages */}
      <div>
        <h2 className="text-xl font-medium text-gray-800 mb-4">Featured Health Packages</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredPackages.map((pkg) => (
            <Card key={pkg.id} className="overflow-hidden">
              <img 
                src={pkg.image} 
                alt={pkg.name} 
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-4">
                <h3 className="font-medium text-gray-800 text-lg">{pkg.name}</h3>
                <p className="mt-1 text-sm text-gray-600">{pkg.description}</p>
                <div className="mt-3 flex justify-between items-center">
                  <span className="text-primary-600 font-medium">{pkg.price}</span>
                  <Link href="/tests">
                    <Button size="sm">Learn More</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
