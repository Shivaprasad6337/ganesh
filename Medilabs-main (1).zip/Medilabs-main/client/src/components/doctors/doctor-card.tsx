import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { BookingModal } from '@/components/booking/booking-modal';

interface Schedule {
  id: number;
  doctor_id: number;
  day: string;
  start_time: string;
  end_time: string;
}

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  qualifications: string;
  bio: string;
  image_url: string;
  schedules?: Schedule[];
}

interface DoctorCardProps {
  doctor: Doctor;
}

export function DoctorCard({ doctor }: DoctorCardProps) {
  const [showBookingModal, setShowBookingModal] = useState(false);
  
  const formatTime = (time: string) => {
    if (!time) return '';
    
    // Convert 24-hour format to 12-hour format
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const formattedHour = hour % 12 || 12; // Convert 0 to 12
    
    return `${formattedHour}:${minutes} ${ampm}`;
  };

  return (
    <>
      <Card className="overflow-hidden border border-gray-200">
        <div className="aspect-w-16 aspect-h-9">
          <img 
            src={doctor.image_url} 
            alt={doctor.name} 
            className="object-cover w-full h-48"
            onError={(e) => {
              // Fallback for image loading errors
              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&w=600&q=80";
            }}
          />
        </div>
        <div className="p-6">
          <div className="flex justify-between items-start">
            <h3 className="font-medium text-gray-800 text-lg">{doctor.name}</h3>
          </div>
          <p className="mt-1 text-sm font-medium text-primary-600">{doctor.specialty}</p>
          <div className="mt-3">
            <h4 className="text-sm font-medium text-gray-800">Available Schedule:</h4>
            <ul className="mt-1 space-y-1">
              {doctor.schedules && doctor.schedules.length > 0 ? (
                doctor.schedules.map((slot) => (
                  <li key={slot.id} className="text-sm text-gray-600">
                    {slot.day}: {formatTime(slot.start_time)} - {formatTime(slot.end_time)}
                  </li>
                ))
              ) : (
                <li className="text-sm text-gray-600">No available schedule</li>
              )}
            </ul>
          </div>
          <div className="mt-4">
            <Button 
              onClick={() => setShowBookingModal(true)}
              className="w-full"
            >
              Book Consultation
            </Button>
          </div>
        </div>
      </Card>

      {showBookingModal && (
        <BookingModal
          type="consultation"
          doctor={doctor}
          test={null}
          open={showBookingModal}
          onClose={() => setShowBookingModal(false)}
        />
      )}
    </>
  );
}
