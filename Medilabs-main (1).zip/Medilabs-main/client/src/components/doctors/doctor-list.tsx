import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DoctorCard } from './doctor-card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Search } from 'lucide-react';

interface Doctor {
  id: number;
  name: string;
  specialty: string;
  qualifications: string;
  bio: string;
  image_url: string;
}

interface DoctorWithSchedule extends Doctor {
  schedules?: Array<{
    id: number;
    doctor_id: number;
    day: string;
    start_time: string;
    end_time: string;
  }>;
}

export function DoctorList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [specialtyFilter, setSpecialtyFilter] = useState('all');
  const [availabilityFilter, setAvailabilityFilter] = useState('any');

  const { data: doctors, isLoading, error } = useQuery<Doctor[]>({
    queryKey: ['/api/doctors'],
  });

  // Extract unique specialties from doctors
  const specialties = doctors ? 
    ['all', ...new Set(doctors.map(doctor => doctor.specialty))]
    : ['all'];

  // Fetch schedules for each doctor
  const doctorsWithSchedules = useQuery<DoctorWithSchedule[]>({
    queryKey: ['/api/doctors/schedules'],
    enabled: !!doctors,
    initialData: [] as DoctorWithSchedule[],
    // This is just to prepare the structure - in a real app we'd make actual API calls
    select: (data) => {
      if (!doctors) return [];
      
      return doctors.map(doctor => {
        // In a real app, this would be fetched from the API
        return {
          ...doctor,
          schedules: []
        };
      });
    }
  });

  // Load individual doctor schedules
  const doctorIds = doctors?.map(doctor => doctor.id) || [];
  
  const doctorSchedulesQueries = useQuery<{ [key: number]: any }>({
    queryKey: ['/api/doctors/schedules/all'],
    enabled: doctorIds.length > 0,
    initialData: {} as { [key: number]: any },
    // In a real app, this would be replaced with actual data from API
    select: () => {
      const schedules: { [key: number]: any } = {};
      
      if (doctors) {
        doctors.forEach(doctor => {
          if (doctor.id === 1) {
            schedules[doctor.id] = [
              { id: 1, doctor_id: 1, day: 'Monday', start_time: '09:00:00', end_time: '15:00:00' },
              { id: 2, doctor_id: 1, day: 'Wednesday', start_time: '13:00:00', end_time: '19:00:00' }
            ];
          } else if (doctor.id === 2) {
            schedules[doctor.id] = [
              { id: 3, doctor_id: 2, day: 'Tuesday', start_time: '10:00:00', end_time: '16:00:00' },
              { id: 4, doctor_id: 2, day: 'Thursday', start_time: '08:00:00', end_time: '14:00:00' }
            ];
          } else if (doctor.id === 3) {
            schedules[doctor.id] = [
              { id: 5, doctor_id: 3, day: 'Monday', start_time: '07:00:00', end_time: '13:00:00' },
              { id: 6, doctor_id: 3, day: 'Friday', start_time: '09:00:00', end_time: '15:00:00' }
            ];
          }
        });
      }
      
      return schedules;
    }
  });

  // Combine doctor data with schedules
  const enhancedDoctors: DoctorWithSchedule[] = doctors?.map(doctor => ({
    ...doctor,
    schedules: doctorSchedulesQueries.data[doctor.id] || []
  })) || [];

  // Filter doctors based on search term and filters
  const filteredDoctors = enhancedDoctors.filter(doctor => {
    // Search filter
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Specialty filter
    const matchesSpecialty = specialtyFilter === 'all' || doctor.specialty === specialtyFilter;
    
    // Availability filter (simplified - would be more complex in a real app)
    let matchesAvailability = true;
    
    if (availabilityFilter !== 'any') {
      // This is a simplified version - would need more complex logic in a real app
      // based on actual schedule availability
      const hasSchedules = doctor.schedules && doctor.schedules.length > 0;
      matchesAvailability = hasSchedules;
    }
    
    return matchesSearch && matchesSpecialty && matchesAvailability;
  });

  // Loading skeleton
  if (isLoading) {
    return (
      <div>
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-grow">
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="sm:w-48">
              <Skeleton className="h-10 w-full" />
            </div>
            <div className="sm:w-48">
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
              <Skeleton className="w-full h-48" />
              <div className="p-6 space-y-4">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return <div className="text-center py-10 text-red-500">Error loading doctors. Please try again later.</div>;
  }

  return (
    <div>
      {/* Search and Filter */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <Input
              type="text"
              className="pl-10"
              placeholder="Search by name or specialty..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="sm:w-48">
            <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Specialties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Specialties</SelectItem>
                {specialties.filter(spec => spec !== 'all').map(specialty => (
                  <SelectItem key={specialty} value={specialty}>
                    {specialty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="sm:w-48">
            <Select value={availabilityFilter} onValueChange={setAvailabilityFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Any Availability" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any Availability</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="this_week">This Week</SelectItem>
                <SelectItem value="next_week">Next Week</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Doctor List */}
      {filteredDoctors && filteredDoctors.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map(doctor => (
            <DoctorCard key={doctor.id} doctor={doctor} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <p className="text-gray-500">No doctors found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}
