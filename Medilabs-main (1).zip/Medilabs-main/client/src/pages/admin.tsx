import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AdminDoctorsList } from '@/components/admin/admin-doctors-list';
import { AddDoctorForm } from '@/components/admin/add-doctor-form';

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('doctors');

  useEffect(() => {
    // Redirect if not authenticated or not an admin
    if (!isAuthenticated) {
      toast({
        title: 'Authentication required',
        description: 'Please log in to access the admin panel.',
        variant: 'destructive',
      });
      setLocation('/login');
    } else if (user?.role !== 'admin') {
      toast({
        title: 'Access denied',
        description: 'You do not have permission to access the admin panel.',
        variant: 'destructive',
      });
      setLocation('/');
    }
  }, [isAuthenticated, user, toast, setLocation]);

  if (!isAuthenticated || user?.role !== 'admin') {
    return null;
  }

  return (
    <div className="container mx-auto py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="gradient-heading text-4xl mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage doctors, tests, and view appointment information</p>
      </div>
      
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 bg-muted/70">
          <TabsTrigger value="doctors" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            Doctors
          </TabsTrigger>
          <TabsTrigger value="tests" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            Tests
          </TabsTrigger>
          <TabsTrigger value="appointments" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
            Appointments
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="doctors" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="admin-section-title">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="text-primary">
                <path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"></path>
                <path d="M3 11v5a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v2H7v-2a2 2 0 0 0-4 0Z"></path>
                <path d="M5 18v2"></path>
                <path d="M19 18v2"></path>
              </svg>
              Manage Doctors
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card className="admin-card shadow">
                <CardHeader className="bg-muted/30 border-b">
                  <CardTitle>Doctors List</CardTitle>
                  <CardDescription>
                    View and manage all doctors in the system
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 overflow-hidden">
                  <AdminDoctorsList />
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card className="admin-card shadow">
                <CardHeader className="bg-muted/30 border-b">
                  <CardTitle>Add New Doctor</CardTitle>
                  <CardDescription>
                    Add a new doctor to the system
                  </CardDescription>
                </CardHeader>
                <CardContent className="form-container border-none p-4">
                  <AddDoctorForm />
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="tests">
          <Card className="admin-card shadow">
            <CardHeader className="bg-muted/30 border-b">
              <CardTitle>Manage Tests</CardTitle>
              <CardDescription>
                Add, edit, or remove diagnostic tests
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="text-muted-foreground mb-4">
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <path d="M12 18v-6"></path>
                  <path d="M9 15h6"></path>
                </svg>
                <p className="text-muted-foreground mb-2">Test management feature coming soon</p>
                <p className="text-sm text-muted-foreground">This feature is currently under development</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="appointments">
          <Card className="admin-card shadow">
            <CardHeader className="bg-muted/30 border-b">
              <CardTitle>Appointments</CardTitle>
              <CardDescription>
                View and manage all patient appointments
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="text-muted-foreground mb-4">
                  <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                  <line x1="16" y1="2" x2="16" y2="6"></line>
                  <line x1="8" y1="2" x2="8" y2="6"></line>
                  <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                <p className="text-muted-foreground mb-2">Appointment management feature coming soon</p>
                <p className="text-sm text-muted-foreground">This feature is currently under development</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}