import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { FlaskRound, UserRound, FileText, CheckCircle } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-primary-50 to-white py-12 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="md:flex md:items-center md:justify-between">
              <div className="md:w-1/2 md:pr-8">
                <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
                  Your Health, Our <span className="text-primary">Priority</span>
                </h1>
                <p className="mt-4 text-lg text-gray-600">
                  MediLabs provides comprehensive diagnostic services with accurate results and expert analysis. Book your tests online and take control of your health journey.
                </p>
                <div className="mt-8 flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                  <Link href="/tests">
                    <Button size="lg" className="w-full sm:w-auto">
                      Book a Test
                    </Button>
                  </Link>
                  <Link href="/register">
                    <Button size="lg" variant="outline" className="w-full sm:w-auto">
                      Create Account
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="mt-8 md:mt-0 md:w-1/2">
                <img 
                  src="https://images.unsplash.com/photo-1581594549595-35f6edc7b762?auto=format&fit=crop&w=1200&h=800&q=80" 
                  alt="Medical laboratory with modern equipment" 
                  className="rounded-lg shadow-lg w-full h-auto"
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Services Section */}
        <section className="py-12 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900">Our Services</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                MediLabs offers a wide range of diagnostic services to help you stay on top of your health.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <FlaskRound className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Diagnostic Tests</h3>
                <p className="text-gray-600">
                  Comprehensive range of diagnostic tests with quick and accurate results.
                </p>
                <Link href="/tests" className="mt-4 text-primary-600 font-medium hover:text-primary-700">
                  Learn More &rarr;
                </Link>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <UserRound className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Doctor Consultations</h3>
                <p className="text-gray-600">
                  Schedule appointments with our experienced specialists for expert medical advice.
                </p>
                <Link href="/doctors" className="mt-4 text-primary-600 font-medium hover:text-primary-700">
                  Learn More &rarr;
                </Link>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200 flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <FileText className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Health Packages</h3>
                <p className="text-gray-600">
                  Comprehensive health packages tailored to your specific needs and concerns.
                </p>
                <Link href="/tests" className="mt-4 text-primary-600 font-medium hover:text-primary-700">
                  Learn More &rarr;
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        {/* Featured Packages Section */}
        <section className="py-12 md:py-20 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900">Featured Health Packages</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                Our comprehensive health packages are designed to provide a complete assessment of your health.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
                <img 
                  src="https://images.unsplash.com/photo-1581594549595-35f6edc7b762?auto=format&fit=crop&w=800&h=450&q=80" 
                  alt="Comprehensive Health Checkup" 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Comprehensive Health Package</h3>
                  <p className="text-gray-600 mb-4">
                    Complete evaluation including CBC, metabolic panel, thyroid tests and more
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-xl font-bold text-primary-600">$199.99</span>
                    <Link href="/tests">
                      <Button>Book Now</Button>
                    </Link>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
                <img 
                  src="https://pixabay.com/get/g57ca6c0d254c0cc3438c89866d7680cff03ae6b4a153129689e96ee7b4bc328d08c2da67c6b41cdd6b1de4ae4d92a920ca59418aab8c75f21e15476357c43ad7_1280.jpg" 
                  alt="Diabetes Screening Package" 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Diabetes Screening</h3>
                  <p className="text-gray-600 mb-4">
                    Includes fasting glucose, HbA1c, and complete diabetes risk assessment
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-xl font-bold text-primary-600">$89.99</span>
                    <Link href="/tests">
                      <Button>Book Now</Button>
                    </Link>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
                <img 
                  src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&h=450&q=80" 
                  alt="Heart Health Package" 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">Heart Health Package</h3>
                  <p className="text-gray-600 mb-4">
                    Comprehensive heart assessment including ECG, lipid panel, and cardiac markers
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-xl font-bold text-primary-600">$149.99</span>
                    <Link href="/tests">
                      <Button>Book Now</Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Why Choose Us Section */}
        <section className="py-12 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900">Why Choose MediLabs</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                We are committed to providing the highest quality diagnostic services with care and compassion.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Accurate Results</h3>
                <p className="text-gray-600">
                  Our state-of-the-art laboratory ensures precise and reliable test results.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Expert Doctors</h3>
                <p className="text-gray-600">
                  Our team of specialists provides expert analysis and personalized care.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Quick Turnaround</h3>
                <p className="text-gray-600">
                  Get your test results quickly, often within 24-48 hours of testing.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Affordable Packages</h3>
                <p className="text-gray-600">
                  Comprehensive health packages at competitive prices for all your needs.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action */}
        <section className="py-12 md:py-20 bg-primary-600 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to take control of your health?</h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Book your diagnostic tests today and take the first step towards a healthier you.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Link href="/register">
                <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                  Create an Account
                </Button>
              </Link>
              <Link href="/tests">
                <Button size="lg" className="bg-white text-primary-600 hover:bg-gray-100 w-full sm:w-auto">
                  Book a Test
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
