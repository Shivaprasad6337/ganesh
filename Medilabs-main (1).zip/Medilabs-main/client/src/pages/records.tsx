import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { RecordList } from '@/components/records/record-list';
import { useAuth } from '@/hooks/use-auth';

export default function Records() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation('/login');
    }
  }, [isAuthenticated, isLoading, setLocation]);

  // Show loading state while checking authentication
  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  // Only render the content if authenticated
  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="py-5">
          <h1 className="text-2xl font-semibold text-gray-900">Medical Records</h1>
          <p className="mt-1 text-sm text-gray-600">View your test results and medical history</p>
        </div>
        
        <RecordList />
      </main>
      
      <Footer />
    </div>
  );
}
