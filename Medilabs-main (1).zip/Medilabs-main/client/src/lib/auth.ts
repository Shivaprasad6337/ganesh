import { jwtDecode } from 'jwt-decode';

interface DecodedToken {
  userId: number;
  email: string;
  role: string;
  exp: number;
}

export function getAuthToken(): string | null {
  return localStorage.getItem('auth-token');
}

export function setAuthToken(token: string): void {
  localStorage.setItem('auth-token', token);
}

export function removeAuthToken(): void {
  localStorage.removeItem('auth-token');
}

export function isTokenValid(token: string): boolean {
  try {
    const decoded = jwtDecode<DecodedToken>(token);
    const currentTime = Date.now() / 1000;
    return decoded.exp > currentTime;
  } catch (error) {
    return false;
  }
}

export function getAuthHeaders(): Headers {
  const token = getAuthToken();
  const headers = new Headers();
  
  if (token) {
    headers.append('Authorization', `Bearer ${token}`);
  }
  
  headers.append('Content-Type', 'application/json');
  return headers;
}

export function redirectToLogin(): void {
  window.location.href = '/login';
}
