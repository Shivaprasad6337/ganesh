import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { jwtDecode } from 'jwt-decode';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: string;
}

interface DecodedToken {
  userId: number;
  email: string;
  role: string;
  exp: number;
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, phone?: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Check for stored token on mount
  useEffect(() => {
    const storedToken = localStorage.getItem('auth-token');
    if (storedToken) {
      try {
        const decoded = jwtDecode<DecodedToken>(storedToken);
        
        // Check if token is expired
        const currentTime = Date.now() / 1000;
        if (decoded.exp < currentTime) {
          // Token expired
          localStorage.removeItem('auth-token');
          setIsLoading(false);
          return;
        }
        
        // Valid token, set user and token
        setUser({
          id: decoded.userId,
          email: decoded.email,
          name: '', // We'll get the full user details below
          role: decoded.role
        });
        setToken(storedToken);
        
        // Fetch user details
        apiRequest('GET', '/api/users/me', undefined)
          .then(res => res.json())
          .then(data => {
            setUser(prev => ({
              ...prev!,
              name: data.name,
            }));
          })
          .catch(() => {
            // If error fetching user, we'll just continue with the decoded token info
          })
          .finally(() => {
            setIsLoading(false);
          });
      } catch (error) {
        // Invalid token
        localStorage.removeItem('auth-token');
        setIsLoading(false);
      }
    } else {
      setIsLoading(false);
    }
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/auth/login', { email, password });
      const data = await response.json();
      
      setUser({
        id: data.user.id,
        name: data.user.name,
        email: data.user.email,
        role: data.user.role
      });
      
      setToken(data.token);
      localStorage.setItem('auth-token', data.token);
      
      toast({
        title: 'Login successful',
        description: `Welcome back, ${data.user.name}!`,
      });
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: 'Login failed',
        description: 'Invalid email or password. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string, phone?: string) => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/auth/register', { 
        name, 
        email, 
        password,
        phone 
      });
      const data = await response.json();
      
      setUser({
        id: data.user.id,
        name: data.user.name,
        email: data.user.email,
        role: data.user.role
      });
      
      setToken(data.token);
      localStorage.setItem('auth-token', data.token);
      
      toast({
        title: 'Registration successful',
        description: `Welcome to MediLabs, ${data.user.name}!`,
      });
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        title: 'Registration failed',
        description: 'Could not create your account. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('auth-token');
    toast({
      title: 'Logged out',
      description: 'You have been successfully logged out.',
    });
  };

  const value = {
    user,
    token,
    isLoading,
    isAuthenticated: !!user,
    login,
    register,
    logout
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
