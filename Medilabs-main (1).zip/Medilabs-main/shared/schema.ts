import {
  pgTable,
  text,
  serial,
  integer,
  boolean,
  timestamp,
  decimal,
  varchar,
  date,
  time,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum("user_role", ["patient", "admin"]);
export const appointmentStatusEnum = pgEnum("appointment_status", [
  "pending",
  "confirmed",
  "cancelled",
  "completed",
]);
export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "completed",
]);
export const testResultStatusEnum = pgEnum("test_result_status", [
  "normal",
  "abnormal",
  "inconclusive",
]);

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  role: userRoleEnum("role").default("patient").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Tests
export const tests = pgTable("tests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  category: text("category"),
  popular: boolean("popular").default(false),
});

// Doctors
export const doctors = pgTable("doctors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  qualifications: text("qualifications"),
  bio: text("bio"),
  image_url: text("image_url"),
});

// Doctor Schedules
export const doctorSchedules = pgTable("doctor_schedules", {
  id: serial("id").primaryKey(),
  doctor_id: integer("doctor_id")
    .references(() => doctors.id)
    .notNull(),
  day: text("day").notNull(), // Monday, Tuesday, etc.
  start_time: time("start_time").notNull(),
  end_time: time("end_time").notNull(),
});

// Appointments
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id")
    .references(() => users.id)
    .notNull(),
  appointment_date: date("appointment_date").notNull(),
  appointment_time: time("appointment_time").notNull(),
  status: appointmentStatusEnum("status").default("pending").notNull(),
  notes: text("notes"),
  created_at: timestamp("created_at").defaultNow().notNull(),
  doctor_id: integer("doctor_id").references(() => doctors.id),
  test_id: integer("test_id").references(() => tests.id),
  type: text("type").notNull(), // 'test' or 'consultation'
  home_collection: boolean("home_collection").default(false), // For home sample collection
  address: text("address"), // Address for home collection
});

// Payments
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  appointment_id: integer("appointment_id")
    .references(() => appointments.id)
    .notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: paymentStatusEnum("status").default("pending").notNull(),
  payment_method: text("payment_method"),
  transaction_id: text("transaction_id"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Bills
export const bills = pgTable("bills", {
  id: serial("id").primaryKey(),
  appointment_id: integer("appointment_id")
    .references(() => appointments.id)
    .notNull(),
  payment_id: integer("payment_id").references(() => payments.id),
  total_amount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  bill_date: timestamp("bill_date").defaultNow().notNull(),
  pdf_url: text("pdf_url"),
});

// Test Results
export const testResults = pgTable("test_results", {
  id: serial("id").primaryKey(),
  appointment_id: integer("appointment_id")
    .references(() => appointments.id)
    .notNull(),
  result_status: testResultStatusEnum("result_status")
    .default("normal")
    .notNull(),
  details: text("details"),
  pdf_url: text("pdf_url"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// Test Suggestions (related tests)
export const testSuggestions = pgTable("test_suggestions", {
  id: serial("id").primaryKey(),
  test_id: integer("test_id")
    .references(() => tests.id)
    .notNull(),
  suggested_test_id: integer("suggested_test_id")
    .references(() => tests.id)
    .notNull(),
});

// Health Packages (combinations of tests)
export const healthPackages = pgTable("health_packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  image_url: text("image_url"),
});

// Health Package Tests (mapping between packages and included tests)
export const healthPackageTests = pgTable("health_package_tests", {
  id: serial("id").primaryKey(),
  package_id: integer("package_id")
    .references(() => healthPackages.id)
    .notNull(),
  test_id: integer("test_id")
    .references(() => tests.id)
    .notNull(),
});

// Zod schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  role: true,
  created_at: true,
});

export const loginUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const insertTestSchema = createInsertSchema(tests).omit({
  id: true,
});

export const insertDoctorSchema = createInsertSchema(doctors).omit({
  id: true,
});

export const insertDoctorScheduleSchema = createInsertSchema(
  doctorSchedules
).omit({
  id: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  created_at: true,
  status: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  created_at: true,
});

export const insertBillSchema = createInsertSchema(bills).omit({
  id: true,
  bill_date: true,
});

export const insertTestResultSchema = createInsertSchema(testResults).omit({
  id: true,
  created_at: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;

export type Test = typeof tests.$inferSelect;
export type InsertTest = z.infer<typeof insertTestSchema>;

export type Doctor = typeof doctors.$inferSelect;
export type InsertDoctor = z.infer<typeof insertDoctorSchema>;

export type DoctorSchedule = typeof doctorSchedules.$inferSelect;
export type InsertDoctorSchedule = z.infer<typeof insertDoctorScheduleSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type Bill = typeof bills.$inferSelect;
export type InsertBill = z.infer<typeof insertBillSchema>;

export type TestResult = typeof testResults.$inferSelect;
export type InsertTestResult = z.infer<typeof insertTestResultSchema>;

export type HealthPackage = typeof healthPackages.$inferSelect;
export type TestSuggestion = typeof testSuggestions.$inferSelect;
