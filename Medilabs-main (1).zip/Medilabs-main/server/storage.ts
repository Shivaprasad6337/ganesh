import {
  users,
  User,
  InsertUser,
  tests,
  Test,
  doctors,
  Doctor,
  InsertDoctor,
  doctorSchedules,
  DoctorSchedule,
  appointments,
  Appointment,
  payments,
  Payment,
  bills,
  Bill,
  testResults,
  TestResult,
  testSuggestions,
  healthPackages,
  HealthPackage,
  healthPackageTests,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import bcrypt from "bcryptjs";

// Define the storage interface for all database operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Test operations
  getAllTests(): Promise<Test[]>;
  getTestById(id: number): Promise<Test | undefined>;
  getTestsByCategory(category: string): Promise<Test[]>;
  getPopularTests(): Promise<Test[]>;
  
  // Doctor operations
  getAllDoctors(): Promise<Doctor[]>;
  getDoctorById(id: number): Promise<Doctor | undefined>;
  getDoctorsBySpecialty(specialty: string): Promise<Doctor[]>;
  getDoctorSchedules(doctorId: number): Promise<DoctorSchedule[]>;
  createDoctor(doctor: InsertDoctor): Promise<Doctor>;
  updateDoctor(id: number, doctor: InsertDoctor): Promise<Doctor>;
  deleteDoctor(id: number): Promise<void>;
  
  // Appointment operations
  createAppointment(appointment: Appointment): Promise<Appointment>;
  getAppointmentsByUserId(userId: number): Promise<Appointment[]>;
  getAppointmentById(id: number): Promise<Appointment | undefined>;
  updateAppointmentStatus(id: number, status: string): Promise<void>;
  
  // Payment operations
  createPayment(payment: Payment): Promise<Payment>;
  getPaymentByAppointmentId(appointmentId: number): Promise<Payment | undefined>;
  updatePaymentStatus(id: number, status: string): Promise<void>;
  
  // Bill operations
  createBill(bill: Bill): Promise<Bill>;
  getBillByAppointmentId(appointmentId: number): Promise<Bill | undefined>;
  
  // Test Result operations
  createTestResult(testResult: TestResult): Promise<TestResult>;
  getTestResultsByUserId(userId: number): Promise<TestResult[]>;
  
  // Test Suggestion operations
  getSuggestedTestsForTest(testId: number): Promise<Test[]>;
  
  // Health Package operations
  getAllHealthPackages(): Promise<HealthPackage[]>;
}

// MySQL implementation of the storage interface
// Note: MySQLStorage is not actively used in this application
// We're keeping it for reference purposes only
export class MySQLStorage implements IStorage {
  private pool: any; // Using any to avoid mysql type errors

  constructor() {
    // Create connection pool
    this.pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'medilabs',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });

    // Initialize database with tables if they don't exist
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    try {
      await this.pool.query(`
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          email VARCHAR(255) NOT NULL UNIQUE,
          password VARCHAR(255) NOT NULL,
          name VARCHAR(255) NOT NULL,
          phone VARCHAR(20),
          role ENUM('patient', 'admin') DEFAULT 'patient' NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS tests (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          description TEXT NOT NULL,
          price DECIMAL(10, 2) NOT NULL,
          category VARCHAR(100),
          popular BOOLEAN DEFAULT FALSE
        );
        
        CREATE TABLE IF NOT EXISTS doctors (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          specialty VARCHAR(255) NOT NULL,
          qualifications TEXT,
          bio TEXT,
          image_url TEXT
        );
        
        CREATE TABLE IF NOT EXISTS doctor_schedules (
          id INT AUTO_INCREMENT PRIMARY KEY,
          doctor_id INT NOT NULL,
          day VARCHAR(20) NOT NULL,
          start_time TIME NOT NULL,
          end_time TIME NOT NULL,
          FOREIGN KEY (doctor_id) REFERENCES doctors(id)
        );
        
        CREATE TABLE IF NOT EXISTS appointments (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          appointment_date DATE NOT NULL,
          appointment_time TIME NOT NULL,
          status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending' NOT NULL,
          notes TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          doctor_id INT,
          test_id INT,
          type VARCHAR(20) NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users(id),
          FOREIGN KEY (doctor_id) REFERENCES doctors(id),
          FOREIGN KEY (test_id) REFERENCES tests(id)
        );
        
        CREATE TABLE IF NOT EXISTS payments (
          id INT AUTO_INCREMENT PRIMARY KEY,
          appointment_id INT NOT NULL,
          amount DECIMAL(10, 2) NOT NULL,
          status ENUM('pending', 'completed') DEFAULT 'pending' NOT NULL,
          payment_method VARCHAR(50),
          transaction_id VARCHAR(255),
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (appointment_id) REFERENCES appointments(id)
        );
        
        CREATE TABLE IF NOT EXISTS bills (
          id INT AUTO_INCREMENT PRIMARY KEY,
          appointment_id INT NOT NULL,
          payment_id INT,
          total_amount DECIMAL(10, 2) NOT NULL,
          bill_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          pdf_url TEXT,
          FOREIGN KEY (appointment_id) REFERENCES appointments(id),
          FOREIGN KEY (payment_id) REFERENCES payments(id)
        );
        
        CREATE TABLE IF NOT EXISTS test_results (
          id INT AUTO_INCREMENT PRIMARY KEY,
          appointment_id INT NOT NULL,
          result_status ENUM('normal', 'abnormal', 'inconclusive') DEFAULT 'normal' NOT NULL,
          details TEXT,
          pdf_url TEXT,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (appointment_id) REFERENCES appointments(id)
        );
        
        CREATE TABLE IF NOT EXISTS test_suggestions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          test_id INT NOT NULL,
          suggested_test_id INT NOT NULL,
          FOREIGN KEY (test_id) REFERENCES tests(id),
          FOREIGN KEY (suggested_test_id) REFERENCES tests(id)
        );
        
        CREATE TABLE IF NOT EXISTS health_packages (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255) NOT NULL,
          description TEXT NOT NULL,
          price DECIMAL(10, 2) NOT NULL,
          image_url TEXT
        );
        
        CREATE TABLE IF NOT EXISTS health_package_tests (
          id INT AUTO_INCREMENT PRIMARY KEY,
          package_id INT NOT NULL,
          test_id INT NOT NULL,
          FOREIGN KEY (package_id) REFERENCES health_packages(id),
          FOREIGN KEY (test_id) REFERENCES tests(id)
        );
      `);

      // Insert some sample data if tables are empty
      await this.insertSampleData();
    } catch (error) {
      console.error('Database initialization error:', error);
    }
  }

  private async insertSampleData() {
    try {
      // Check if tests table is empty
      const [testRows]: any = await this.pool.query('SELECT COUNT(*) as count FROM tests');
      if (testRows[0].count === 0) {
        // Insert sample tests
        await this.pool.query(`
          INSERT INTO tests (name, description, price, category, popular) VALUES
          ('Complete Blood Count (CBC)', 'Measures several components of your blood including red and white blood cells, platelets, and hemoglobin.', 42.99, 'Blood Tests', TRUE),
          ('Comprehensive Metabolic Panel', 'Tests your liver and kidney function, sugar levels, and electrolyte balance.', 56.00, 'Blood Tests', TRUE),
          ('Lipid Panel', 'Measures cholesterol levels to assess risk of heart disease.', 36.50, 'Blood Tests', TRUE),
          ('Thyroid Function Tests', 'Analyzes thyroid hormone levels to check thyroid health.', 85.99, 'Endocrine Tests', FALSE),
          ('Hemoglobin A1C', 'Measures average blood sugar levels over the past 3 months.', 47.25, 'Diabetes Tests', TRUE);
        `);
      }

      // Check if doctors table is empty
      const [doctorRows]: any = await this.pool.query('SELECT COUNT(*) as count FROM doctors');
      if (doctorRows[0].count === 0) {
        // Insert sample doctors
        await this.pool.query(`
          INSERT INTO doctors (name, specialty, qualifications, bio, image_url) VALUES
          ('Dr. Sarah Johnson', 'Cardiology', 'MD, FACC', 'Dr. Johnson specializes in cardiovascular health and preventive care.', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=600&q=80'),
          ('Dr. Michael Rodriguez', 'Endocrinology', 'MD, PhD', 'Dr. Rodriguez is an expert in diabetes management and thyroid disorders.', 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80'),
          ('Dr. Lisa Chen', 'Pathology', 'MD, FCAP', 'Dr. Chen specializes in laboratory medicine and diagnostic testing.', 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=600&q=80');
        `);

        // Insert sample doctor schedules
        await this.pool.query(`
          INSERT INTO doctor_schedules (doctor_id, day, start_time, end_time) VALUES
          (1, 'Monday', '09:00:00', '15:00:00'),
          (1, 'Wednesday', '13:00:00', '19:00:00'),
          (2, 'Tuesday', '10:00:00', '16:00:00'),
          (2, 'Thursday', '08:00:00', '14:00:00'),
          (3, 'Monday', '07:00:00', '13:00:00'),
          (3, 'Friday', '09:00:00', '15:00:00');
        `);
      }

      // Check if health packages table is empty
      const [packageRows]: any = await this.pool.query('SELECT COUNT(*) as count FROM health_packages');
      if (packageRows[0].count === 0) {
        // Insert sample health packages
        await this.pool.query(`
          INSERT INTO health_packages (name, description, price, image_url) VALUES
          ('Comprehensive Wellness Package', 'Complete health assessment with 45+ essential tests', 249.99, 'https://images.unsplash.com/photo-1581594549595-35f6edc7b762?auto=format&fit=crop&w=800&h=450&q=80'),
          ('Diabetes Care Package', 'Complete diabetes screening and management tests', 129.99, 'https://pixabay.com/get/g57ca6c0d254c0cc3438c89866d7680cff03ae6b4a153129689e96ee7b4bc328d08c2da67c6b41cdd6b1de4ae4d92a920ca59418aab8c75f21e15476357c43ad7_1280.jpg'),
          ('Heart Health Package', 'Comprehensive cardiac risk assessment', 179.99, 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&h=450&q=80');
        `);
      }

      // Check if test_suggestions table is empty
      const [suggestionRows]: any = await this.pool.query('SELECT COUNT(*) as count FROM test_suggestions');
      if (suggestionRows[0].count === 0) {
        // Insert sample test suggestions
        await this.pool.query(`
          INSERT INTO test_suggestions (test_id, suggested_test_id) VALUES
          (5, 3), -- If user books Hemoglobin A1C, suggest Lipid Panel
          (5, 2), -- If user books Hemoglobin A1C, suggest Comprehensive Metabolic Panel
          (3, 1), -- If user books Lipid Panel, suggest CBC
          (3, 4), -- If user books Lipid Panel, suggest Thyroid Test
          (1, 2); -- If user books CBC, suggest Comprehensive Metabolic Panel
        `);
      }
    } catch (error) {
      console.error('Error inserting sample data:', error);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [rows]: any = await this.pool.query(
      'SELECT id, email, name, phone, role, created_at FROM users WHERE id = ?',
      [id]
    );
    return rows.length > 0 ? rows[0] as User : undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    return rows.length > 0 ? rows[0] as User : undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    // Hash the password
    const hashedPassword = await bcrypt.hash(user.password, 10);
    
    const [result]: any = await this.pool.query(
      'INSERT INTO users (email, password, name, phone) VALUES (?, ?, ?, ?)',
      [user.email, hashedPassword, user.name, user.phone]
    );
    
    const insertedId = result.insertId;
    return this.getUser(insertedId) as Promise<User>;
  }

  // Test operations
  async getAllTests(): Promise<Test[]> {
    const [rows]: any = await this.pool.query('SELECT * FROM tests');
    return rows as Test[];
  }

  async getTestById(id: number): Promise<Test | undefined> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM tests WHERE id = ?',
      [id]
    );
    return rows.length > 0 ? rows[0] as Test : undefined;
  }

  async getTestsByCategory(category: string): Promise<Test[]> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM tests WHERE category = ?',
      [category]
    );
    return rows as Test[];
  }

  async getPopularTests(): Promise<Test[]> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM tests WHERE popular = TRUE'
    );
    return rows as Test[];
  }

  // Doctor operations
  async getAllDoctors(): Promise<Doctor[]> {
    const [rows]: any = await this.pool.query('SELECT * FROM doctors');
    return rows as Doctor[];
  }

  async getDoctorById(id: number): Promise<Doctor | undefined> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM doctors WHERE id = ?',
      [id]
    );
    return rows.length > 0 ? rows[0] as Doctor : undefined;
  }

  async getDoctorsBySpecialty(specialty: string): Promise<Doctor[]> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM doctors WHERE specialty = ?',
      [specialty]
    );
    return rows as Doctor[];
  }

  async getDoctorSchedules(doctorId: number): Promise<DoctorSchedule[]> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM doctor_schedules WHERE doctor_id = ?',
      [doctorId]
    );
    return rows as DoctorSchedule[];
  }

  // Appointment operations
  async createAppointment(appointment: any): Promise<Appointment> {
    const [result]: any = await this.pool.query(
      'INSERT INTO appointments (user_id, appointment_date, appointment_time, status, notes, doctor_id, test_id, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [
        appointment.user_id,
        appointment.appointment_date,
        appointment.appointment_time,
        appointment.status || 'pending',
        appointment.notes,
        appointment.doctor_id,
        appointment.test_id,
        appointment.type
      ]
    );
    
    const insertedId = result.insertId;
    const [rows]: any = await this.pool.query(
      'SELECT * FROM appointments WHERE id = ?',
      [insertedId]
    );
    return rows[0] as Appointment;
  }

  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    const [rows]: any = await this.pool.query(
      `SELECT a.*, 
        t.name as test_name, t.price as test_price,
        d.name as doctor_name, d.specialty as doctor_specialty
       FROM appointments a
       LEFT JOIN tests t ON a.test_id = t.id
       LEFT JOIN doctors d ON a.doctor_id = d.id
       WHERE a.user_id = ?
       ORDER BY a.appointment_date DESC, a.appointment_time DESC`,
      [userId]
    );
    return rows as Appointment[];
  }

  async getAppointmentById(id: number): Promise<Appointment | undefined> {
    const [rows]: any = await this.pool.query(
      `SELECT a.*, 
        t.name as test_name, t.price as test_price,
        d.name as doctor_name, d.specialty as doctor_specialty
       FROM appointments a
       LEFT JOIN tests t ON a.test_id = t.id
       LEFT JOIN doctors d ON a.doctor_id = d.id
       WHERE a.id = ?`,
      [id]
    );
    return rows.length > 0 ? rows[0] as Appointment : undefined;
  }

  async updateAppointmentStatus(id: number, status: string): Promise<void> {
    await this.pool.query(
      'UPDATE appointments SET status = ? WHERE id = ?',
      [status, id]
    );
  }

  // Payment operations
  async createPayment(payment: Payment): Promise<Payment> {
    const [result]: any = await this.pool.query(
      'INSERT INTO payments (appointment_id, amount, status, payment_method, transaction_id) VALUES (?, ?, ?, ?, ?)',
      [
        payment.appointment_id,
        payment.amount,
        payment.status || 'pending',
        payment.payment_method,
        payment.transaction_id
      ]
    );
    
    const insertedId = result.insertId;
    const [rows]: any = await this.pool.query(
      'SELECT * FROM payments WHERE id = ?',
      [insertedId]
    );
    return rows[0] as Payment;
  }

  async getPaymentByAppointmentId(appointmentId: number): Promise<Payment | undefined> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM payments WHERE appointment_id = ?',
      [appointmentId]
    );
    return rows.length > 0 ? rows[0] as Payment : undefined;
  }

  async updatePaymentStatus(id: number, status: string): Promise<void> {
    await this.pool.query(
      'UPDATE payments SET status = ? WHERE id = ?',
      [status, id]
    );
  }

  // Bill operations
  async createBill(bill: Bill): Promise<Bill> {
    const [result]: any = await this.pool.query(
      'INSERT INTO bills (appointment_id, payment_id, total_amount, pdf_url) VALUES (?, ?, ?, ?)',
      [
        bill.appointment_id,
        bill.payment_id,
        bill.total_amount,
        bill.pdf_url
      ]
    );
    
    const insertedId = result.insertId;
    const [rows]: any = await this.pool.query(
      'SELECT * FROM bills WHERE id = ?',
      [insertedId]
    );
    return rows[0] as Bill;
  }

  async getBillByAppointmentId(appointmentId: number): Promise<Bill | undefined> {
    const [rows]: any = await this.pool.query(
      'SELECT * FROM bills WHERE appointment_id = ?',
      [appointmentId]
    );
    return rows.length > 0 ? rows[0] as Bill : undefined;
  }

  // Test Result operations
  async createTestResult(testResult: TestResult): Promise<TestResult> {
    const [result]: any = await this.pool.query(
      'INSERT INTO test_results (appointment_id, result_status, details, pdf_url) VALUES (?, ?, ?, ?)',
      [
        testResult.appointment_id,
        testResult.result_status,
        testResult.details,
        testResult.pdf_url
      ]
    );
    
    const insertedId = result.insertId;
    const [rows]: any = await this.pool.query(
      'SELECT * FROM test_results WHERE id = ?',
      [insertedId]
    );
    return rows[0] as TestResult;
  }

  async getTestResultsByUserId(userId: number): Promise<TestResult[]> {
    const [rows]: any = await this.pool.query(
      `SELECT tr.*, a.appointment_date, t.name as test_name
       FROM test_results tr
       JOIN appointments a ON tr.appointment_id = a.id
       LEFT JOIN tests t ON a.test_id = t.id
       WHERE a.user_id = ?
       ORDER BY tr.created_at DESC`,
      [userId]
    );
    return rows as TestResult[];
  }

  // Test Suggestion operations
  async getSuggestedTestsForTest(testId: number): Promise<Test[]> {
    const [rows]: any = await this.pool.query(
      `SELECT t.*
       FROM test_suggestions ts
       JOIN tests t ON ts.suggested_test_id = t.id
       WHERE ts.test_id = ?`,
      [testId]
    );
    return rows as Test[];
  }

  // Health Package operations
  async getAllHealthPackages(): Promise<HealthPackage[]> {
    const [rows]: any = await this.pool.query('SELECT * FROM health_packages');
    return rows as HealthPackage[];
  }
}

// Use in-memory storage for development/testing
export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private tests: Map<number, Test> = new Map();
  private doctors: Map<number, Doctor> = new Map();
  private doctorSchedules: Map<number, DoctorSchedule[]> = new Map();
  private appointments: Map<number, Appointment> = new Map();
  private userAppointments: Map<number, number[]> = new Map();
  private payments: Map<number, Payment> = new Map();
  private appointmentPayments: Map<number, number> = new Map();
  private bills: Map<number, Bill> = new Map();
  private appointmentBills: Map<number, number> = new Map();
  private testResults: Map<number, TestResult> = new Map();
  private userTestResults: Map<number, number[]> = new Map();
  private testSuggestions: Map<number, number[]> = new Map();
  private healthPackages: Map<number, HealthPackage> = new Map();
  
  private nextUserId = 1;
  private nextTestId = 1;
  private nextDoctorId = 1;
  private nextScheduleId = 1;
  private nextAppointmentId = 1;
  private nextPaymentId = 1;
  private nextBillId = 1;
  private nextResultId = 1;
  private nextPackageId = 1;

  constructor() {
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample tests
    const tests: Test[] = [
      {
        id: this.nextTestId++,
        name: 'Complete Blood Count (CBC)',
        description: 'Measures several components of your blood including red and white blood cells, platelets, and hemoglobin.',
        price: "42.99",
        category: 'Blood Tests',
        popular: true
      },
      {
        id: this.nextTestId++,
        name: 'Comprehensive Metabolic Panel',
        description: 'Tests your liver and kidney function, sugar levels, and electrolyte balance.',
        price: "56.00",
        category: 'Blood Tests',
        popular: true
      },
      {
        id: this.nextTestId++,
        name: 'Lipid Panel',
        description: 'Measures cholesterol levels to assess risk of heart disease.',
        price: "36.50",
        category: 'Blood Tests',
        popular: true
      },
      {
        id: this.nextTestId++,
        name: 'Thyroid Function Tests',
        description: 'Analyzes thyroid hormone levels to check thyroid health.',
        price: "85.99",
        category: 'Endocrine Tests',
        popular: false
      },
      {
        id: this.nextTestId++,
        name: 'Hemoglobin A1C',
        description: 'Measures average blood sugar levels over the past 3 months.',
        price: "47.25",
        category: 'Diabetes Tests',
        popular: true
      }
    ];

    tests.forEach(test => this.tests.set(test.id, test));

    // Sample doctors
    const doctors: Doctor[] = [
      {
        id: this.nextDoctorId++,
        name: 'Dr. Sarah Johnson',
        specialty: 'Cardiology',
        qualifications: 'MD, FACC',
        bio: 'Dr. Johnson specializes in cardiovascular health and preventive care.',
        image_url: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=600&q=80'
      },
      {
        id: this.nextDoctorId++,
        name: 'Dr. Michael Rodriguez',
        specialty: 'Endocrinology',
        qualifications: 'MD, PhD',
        bio: 'Dr. Rodriguez is an expert in diabetes management and thyroid disorders.',
        image_url: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80'
      },
      {
        id: this.nextDoctorId++,
        name: 'Dr. Lisa Chen',
        specialty: 'Pathology',
        qualifications: 'MD, FCAP',
        bio: 'Dr. Chen specializes in laboratory medicine and diagnostic testing.',
        image_url: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=600&q=80'
      }
    ];

    doctors.forEach(doctor => this.doctors.set(doctor.id, doctor));

    // Sample doctor schedules
    const schedules: DoctorSchedule[] = [
      {
        id: this.nextScheduleId++,
        doctor_id: 1,
        day: 'Monday',
        start_time: '09:00:00',
        end_time: '15:00:00'
      },
      {
        id: this.nextScheduleId++,
        doctor_id: 1,
        day: 'Wednesday',
        start_time: '13:00:00',
        end_time: '19:00:00'
      },
      {
        id: this.nextScheduleId++,
        doctor_id: 2,
        day: 'Tuesday',
        start_time: '10:00:00',
        end_time: '16:00:00'
      },
      {
        id: this.nextScheduleId++,
        doctor_id: 2,
        day: 'Thursday',
        start_time: '08:00:00',
        end_time: '14:00:00'
      },
      {
        id: this.nextScheduleId++,
        doctor_id: 3,
        day: 'Monday',
        start_time: '07:00:00',
        end_time: '13:00:00'
      },
      {
        id: this.nextScheduleId++,
        doctor_id: 3,
        day: 'Friday',
        start_time: '09:00:00',
        end_time: '15:00:00'
      }
    ];

    schedules.forEach(schedule => {
      if (!this.doctorSchedules.has(schedule.doctor_id)) {
        this.doctorSchedules.set(schedule.doctor_id, []);
      }
      this.doctorSchedules.get(schedule.doctor_id)?.push(schedule);
    });

    // Sample health packages
    const packages: HealthPackage[] = [
      {
        id: this.nextPackageId++,
        name: 'Comprehensive Wellness Package',
        description: 'Complete health assessment with 45+ essential tests',
        price: "249.99",
        image_url: 'https://images.unsplash.com/photo-1581594549595-35f6edc7b762?auto=format&fit=crop&w=800&h=450&q=80'
      },
      {
        id: this.nextPackageId++,
        name: 'Diabetes Care Package',
        description: 'Complete diabetes screening and management tests',
        price: "129.99",
        image_url: 'https://pixabay.com/get/g57ca6c0d254c0cc3438c89866d7680cff03ae6b4a153129689e96ee7b4bc328d08c2da67c6b41cdd6b1de4ae4d92a920ca59418aab8c75f21e15476357c43ad7_1280.jpg'
      },
      {
        id: this.nextPackageId++,
        name: 'Heart Health Package',
        description: 'Comprehensive cardiac risk assessment',
        price: "179.99",
        image_url: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&h=450&q=80'
      }
    ];

    packages.forEach(pkg => this.healthPackages.set(pkg.id, pkg));

    // Test suggestions
    this.testSuggestions.set(5, [3, 2]); // Hemoglobin A1C suggests Lipid Panel and Metabolic Panel
    this.testSuggestions.set(3, [1, 4]); // Lipid Panel suggests CBC and Thyroid Tests
    this.testSuggestions.set(1, [2]);    // CBC suggests Metabolic Panel
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(user: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(user.password, 10);
    
    const newUser: User = {
      id: this.nextUserId++,
      email: user.email,
      password: hashedPassword,
      name: user.name,
      phone: user.phone,
      role: 'patient',
      created_at: new Date().toISOString()
    };
    
    this.users.set(newUser.id, newUser);
    return newUser;
  }

  // Test operations
  async getAllTests(): Promise<Test[]> {
    return Array.from(this.tests.values());
  }

  async getTestById(id: number): Promise<Test | undefined> {
    return this.tests.get(id);
  }

  async getTestsByCategory(category: string): Promise<Test[]> {
    return Array.from(this.tests.values()).filter(test => test.category === category);
  }

  async getPopularTests(): Promise<Test[]> {
    return Array.from(this.tests.values()).filter(test => test.popular);
  }

  // Doctor operations
  async getAllDoctors(): Promise<Doctor[]> {
    return Array.from(this.doctors.values());
  }

  async getDoctorById(id: number): Promise<Doctor | undefined> {
    return this.doctors.get(id);
  }

  async getDoctorsBySpecialty(specialty: string): Promise<Doctor[]> {
    return Array.from(this.doctors.values()).filter(doctor => doctor.specialty === specialty);
  }

  async getDoctorSchedules(doctorId: number): Promise<DoctorSchedule[]> {
    return this.doctorSchedules.get(doctorId) || [];
  }

  async createDoctor(doctor: InsertDoctor): Promise<Doctor> {
    const newDoctor: Doctor = {
      id: this.nextDoctorId++,
      name: doctor.name,
      specialty: doctor.specialty,
      qualifications: doctor.qualifications,
      bio: doctor.bio,
      image_url: doctor.image_url || null,
      created_at: new Date()
    };
    
    this.doctors.set(newDoctor.id, newDoctor);
    return newDoctor;
  }

  async updateDoctor(id: number, doctor: InsertDoctor): Promise<Doctor> {
    const existingDoctor = this.doctors.get(id);
    
    if (!existingDoctor) {
      throw new Error(`Doctor with ID ${id} not found`);
    }
    
    const updatedDoctor: Doctor = {
      ...existingDoctor,
      name: doctor.name,
      specialty: doctor.specialty,
      qualifications: doctor.qualifications,
      bio: doctor.bio,
      image_url: doctor.image_url || null
    };
    
    this.doctors.set(id, updatedDoctor);
    return updatedDoctor;
  }

  async deleteDoctor(id: number): Promise<void> {
    const exists = this.doctors.has(id);
    
    if (!exists) {
      throw new Error(`Doctor with ID ${id} not found`);
    }
    
    this.doctors.delete(id);
    
    // Also delete any associated schedules
    this.doctorSchedules.delete(id);
  }

  // Appointment operations
  async createAppointment(appointment: any): Promise<Appointment> {
    const newAppointment: Appointment = {
      id: this.nextAppointmentId++,
      user_id: appointment.user_id,
      appointment_date: appointment.appointment_date,
      appointment_time: appointment.appointment_time,
      status: appointment.status || 'pending',
      notes: appointment.notes,
      created_at: new Date().toISOString(),
      doctor_id: appointment.doctor_id,
      test_id: appointment.test_id,
      type: appointment.type
    };
    
    this.appointments.set(newAppointment.id, newAppointment);
    
    // Track appointments by user
    if (!this.userAppointments.has(newAppointment.user_id)) {
      this.userAppointments.set(newAppointment.user_id, []);
    }
    this.userAppointments.get(newAppointment.user_id)?.push(newAppointment.id);
    
    return newAppointment;
  }

  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    const appointmentIds = this.userAppointments.get(userId) || [];
    return appointmentIds.map(id => this.appointments.get(id)!).filter(Boolean);
  }

  async getAppointmentById(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async updateAppointmentStatus(id: number, status: string): Promise<void> {
    const appointment = this.appointments.get(id);
    if (appointment) {
      appointment.status = status as any;
      this.appointments.set(id, appointment);
    }
  }

  // Payment operations
  async createPayment(payment: Payment): Promise<Payment> {
    const newPayment: Payment = {
      id: this.nextPaymentId++,
      appointment_id: payment.appointment_id,
      amount: payment.amount,
      status: payment.status || 'pending',
      payment_method: payment.payment_method,
      transaction_id: payment.transaction_id,
      created_at: new Date().toISOString()
    };
    
    this.payments.set(newPayment.id, newPayment);
    this.appointmentPayments.set(newPayment.appointment_id, newPayment.id);
    
    return newPayment;
  }

  async getPaymentByAppointmentId(appointmentId: number): Promise<Payment | undefined> {
    const paymentId = this.appointmentPayments.get(appointmentId);
    return paymentId ? this.payments.get(paymentId) : undefined;
  }

  async updatePaymentStatus(id: number, status: string): Promise<void> {
    const payment = this.payments.get(id);
    if (payment) {
      payment.status = status as any;
      this.payments.set(id, payment);
    }
  }

  // Bill operations
  async createBill(bill: Bill): Promise<Bill> {
    const newBill: Bill = {
      id: this.nextBillId++,
      appointment_id: bill.appointment_id,
      payment_id: bill.payment_id,
      total_amount: bill.total_amount,
      bill_date: new Date().toISOString(),
      pdf_url: bill.pdf_url
    };
    
    this.bills.set(newBill.id, newBill);
    this.appointmentBills.set(newBill.appointment_id, newBill.id);
    
    return newBill;
  }

  async getBillByAppointmentId(appointmentId: number): Promise<Bill | undefined> {
    const billId = this.appointmentBills.get(appointmentId);
    return billId ? this.bills.get(billId) : undefined;
  }

  // Test Result operations
  async createTestResult(testResult: TestResult): Promise<TestResult> {
    const newResult: TestResult = {
      id: this.nextResultId++,
      appointment_id: testResult.appointment_id,
      result_status: testResult.result_status,
      details: testResult.details,
      pdf_url: testResult.pdf_url,
      created_at: new Date().toISOString()
    };
    
    this.testResults.set(newResult.id, newResult);
    
    // Track results by appointment
    const appointment = this.appointments.get(testResult.appointment_id);
    if (appointment) {
      const userId = appointment.user_id;
      if (!this.userTestResults.has(userId)) {
        this.userTestResults.set(userId, []);
      }
      this.userTestResults.get(userId)?.push(newResult.id);
    }
    
    return newResult;
  }

  async getTestResultsByUserId(userId: number): Promise<TestResult[]> {
    const resultIds = this.userTestResults.get(userId) || [];
    return resultIds.map(id => this.testResults.get(id)!).filter(Boolean);
  }

  // Test Suggestion operations
  async getSuggestedTestsForTest(testId: number): Promise<Test[]> {
    const suggestedIds = this.testSuggestions.get(testId) || [];
    return suggestedIds.map(id => this.tests.get(id)!).filter(Boolean);
  }

  // Health Package operations
  async getAllHealthPackages(): Promise<HealthPackage[]> {
    return Array.from(this.healthPackages.values());
  }
}

// Export the storage implementation based on environment
import { db } from "./db";

// Implement the DatabaseStorage class that uses PostgreSQL with Drizzle ORM
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    return newUser;
  }
  
  // Test operations
  async getAllTests(): Promise<Test[]> {
    return await db.select().from(tests);
  }

  async getTestById(id: number): Promise<Test | undefined> {
    const [test] = await db.select().from(tests).where(eq(tests.id, id));
    return test || undefined;
  }

  async getTestsByCategory(category: string): Promise<Test[]> {
    return await db.select().from(tests).where(eq(tests.category, category));
  }

  async getPopularTests(): Promise<Test[]> {
    return await db.select().from(tests).where(eq(tests.popular, true));
  }
  
  // Doctor operations
  async getAllDoctors(): Promise<Doctor[]> {
    return await db.select().from(doctors);
  }

  async getDoctorById(id: number): Promise<Doctor | undefined> {
    const [doctor] = await db.select().from(doctors).where(eq(doctors.id, id));
    return doctor || undefined;
  }

  async getDoctorsBySpecialty(specialty: string): Promise<Doctor[]> {
    return await db.select().from(doctors).where(eq(doctors.specialty, specialty));
  }

  async getDoctorSchedules(doctorId: number): Promise<DoctorSchedule[]> {
    return await db.select().from(doctorSchedules).where(eq(doctorSchedules.doctor_id, doctorId));
  }
  
  async createDoctor(doctorData: InsertDoctor): Promise<Doctor> {
    const [doctor] = await db.insert(doctors).values(doctorData).returning();
    return doctor;
  }

  async updateDoctor(id: number, doctorData: InsertDoctor): Promise<Doctor> {
    const [doctor] = await db
      .update(doctors)
      .set({
        name: doctorData.name,
        specialty: doctorData.specialty,
        qualifications: doctorData.qualifications,
        bio: doctorData.bio,
        image_url: doctorData.image_url
      })
      .where(eq(doctors.id, id))
      .returning();
    return doctor;
  }

  async deleteDoctor(id: number): Promise<void> {
    await db.delete(doctors).where(eq(doctors.id, id));
  }
  
  // Appointment operations
  async createAppointment(appointmentData: any): Promise<Appointment> {
    // Add default created_at field with current date if not provided
    const dataWithCreatedAt = {
      ...appointmentData,
      created_at: new Date()
    };
    
    const [appointment] = await db
      .insert(appointments)
      .values(dataWithCreatedAt)
      .returning();
    return appointment;
  }

  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    // Join to get test and doctor information
    const appointmentsData = await db
      .select({
        id: appointments.id,
        user_id: appointments.user_id,
        appointment_date: appointments.appointment_date,
        appointment_time: appointments.appointment_time,
        status: appointments.status,
        notes: appointments.notes,
        created_at: appointments.created_at,
        doctor_id: appointments.doctor_id,
        test_id: appointments.test_id,
        type: appointments.type,
        test_name: tests.name,
        test_price: tests.price,
        doctor_name: doctors.name,
        doctor_specialty: doctors.specialty,
      })
      .from(appointments)
      .leftJoin(tests, eq(appointments.test_id, tests.id))
      .leftJoin(doctors, eq(appointments.doctor_id, doctors.id))
      .where(eq(appointments.user_id, userId))
      .orderBy(desc(appointments.appointment_date), desc(appointments.appointment_time));
    
    return appointmentsData.map(appt => ({
      id: appt.id,
      user_id: appt.user_id,
      appointment_date: appt.appointment_date,
      appointment_time: appt.appointment_time,
      status: appt.status,
      notes: appt.notes,
      created_at: appt.created_at,
      doctor_id: appt.doctor_id,
      test_id: appt.test_id,
      type: appt.type,
      test_name: appt.test_name,
      test_price: appt.test_price,
      doctor_name: appt.doctor_name,
      doctor_specialty: appt.doctor_specialty,
      payment: { status: 'pending' } // Default payment info
    })) as Appointment[];
  }

  async getAppointmentById(id: number): Promise<Appointment | undefined> {
    const [appt] = await db
      .select({
        id: appointments.id,
        user_id: appointments.user_id,
        appointment_date: appointments.appointment_date,
        appointment_time: appointments.appointment_time,
        status: appointments.status,
        notes: appointments.notes,
        created_at: appointments.created_at,
        doctor_id: appointments.doctor_id,
        test_id: appointments.test_id,
        type: appointments.type,
        test_name: tests.name,
        test_price: tests.price,
        doctor_name: doctors.name,
        doctor_specialty: doctors.specialty,
      })
      .from(appointments)
      .leftJoin(tests, eq(appointments.test_id, tests.id))
      .leftJoin(doctors, eq(appointments.doctor_id, doctors.id))
      .where(eq(appointments.id, id));
    
    if (!appt) return undefined;
    
    return {
      id: appt.id,
      user_id: appt.user_id,
      appointment_date: appt.appointment_date,
      appointment_time: appt.appointment_time,
      status: appt.status,
      notes: appt.notes,
      created_at: appt.created_at,
      doctor_id: appt.doctor_id,
      test_id: appt.test_id,
      type: appt.type,
      test_name: appt.test_name,
      test_price: appt.test_price,
      doctor_name: appt.doctor_name,
      doctor_specialty: appt.doctor_specialty,
      payment: { status: 'pending' } // Default payment info
    } as Appointment;
  }

  async updateAppointmentStatus(id: number, status: string): Promise<void> {
    await db
      .update(appointments)
      .set({ status: status as any })
      .where(eq(appointments.id, id));
  }
  
  // Payment operations
  async createPayment(paymentData: any): Promise<Payment> {
    // We don't provide the ID as PostgreSQL will auto-generate it
    const { id, ...dataToInsert } = paymentData;
    
    const [newPayment] = await db
      .insert(payments)
      .values(dataToInsert)
      .returning();
    return newPayment;
  }

  async getPaymentByAppointmentId(appointmentId: number): Promise<Payment | undefined> {
    const [payment] = await db
      .select()
      .from(payments)
      .where(eq(payments.appointment_id, appointmentId));
    return payment || undefined;
  }

  async updatePaymentStatus(id: number, status: string): Promise<void> {
    await db
      .update(payments)
      .set({ status: status as any })
      .where(eq(payments.id, id));
  }
  
  // Bill operations
  async createBill(billData: any): Promise<Bill> {
    // We don't provide the ID as PostgreSQL will auto-generate it
    const { id, ...dataToInsert } = billData;
    
    const [newBill] = await db
      .insert(bills)
      .values(dataToInsert)
      .returning();
    return newBill;
  }

  async getBillByAppointmentId(appointmentId: number): Promise<Bill | undefined> {
    const [bill] = await db
      .select()
      .from(bills)
      .where(eq(bills.appointment_id, appointmentId));
    return bill || undefined;
  }
  
  // Test Result operations
  async createTestResult(testResult: TestResult): Promise<TestResult> {
    const [newTestResult] = await db
      .insert(testResults)
      .values(testResult)
      .returning();
    return newTestResult;
  }

  async getTestResultsByUserId(userId: number): Promise<TestResult[]> {
    const resultsData = await db
      .select({
        id: testResults.id,
        appointment_id: testResults.appointment_id,
        result_status: testResults.result_status,
        details: testResults.details,
        pdf_url: testResults.pdf_url,
        created_at: testResults.created_at,
        test_name: tests.name,
        appointment_date: appointments.appointment_date,
      })
      .from(testResults)
      .innerJoin(appointments, eq(testResults.appointment_id, appointments.id))
      .leftJoin(tests, eq(appointments.test_id, tests.id))
      .where(eq(appointments.user_id, userId));
    
    return resultsData.map(result => ({
      id: result.id,
      appointment_id: result.appointment_id,
      result_status: result.result_status,
      details: result.details,
      pdf_url: result.pdf_url,
      created_at: result.created_at,
      test_name: result.test_name,
      appointment_date: result.appointment_date
    })) as TestResult[];
  }
  
  // Test Suggestion operations
  async getSuggestedTestsForTest(testId: number): Promise<Test[]> {
    const suggestedTestsData = await db
      .select({
        id: tests.id,
        name: tests.name,
        description: tests.description,
        price: tests.price,
        category: tests.category,
        popular: tests.popular
      })
      .from(testSuggestions)
      .innerJoin(tests, eq(testSuggestions.suggested_test_id, tests.id))
      .where(eq(testSuggestions.test_id, testId));
    
    return suggestedTestsData as Test[];
  }
  
  // Health Package operations
  async getAllHealthPackages(): Promise<HealthPackage[]> {
    return await db.select().from(healthPackages);
  }
}

export const storage = new DatabaseStorage();
