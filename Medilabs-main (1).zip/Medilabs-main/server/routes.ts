import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { loginUserSchema, insertUserSchema } from "@shared/schema";
import { authMiddleware, adminMiddleware } from "./middleware/auth";
import { format } from "date-fns";
import { insertDoctorSchema } from "@shared/schema";

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || "medilabs-secret-key";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.use("/api", (req, res, next) => {
    // Set CORS headers for API routes
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
    res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
    next();
  });

  // Authentication Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const parseResult = insertUserSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: parseResult.error.errors 
        });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(parseResult.data.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }
      
      // Create new user
      const user = await storage.createUser(parseResult.data);
      
      // Create JWT token
      const token = jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: "7d" }
      );
      
      // Return user info (without password) and token
      res.status(201).json({
        message: "User registered successfully",
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        },
        token
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Server error during registration" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const parseResult = loginUserSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: parseResult.error.errors 
        });
      }
      
      // Check if user exists
      const user = await storage.getUserByEmail(parseResult.data.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Verify password
      const isPasswordValid = await bcrypt.compare(parseResult.data.password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Create JWT token
      const token = jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: "7d" }
      );
      
      // Return user info (without password) and token
      res.status(200).json({
        message: "Login successful",
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        },
        token
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Server error during login" });
    }
  });

  // Test API Routes
  app.get("/api/tests", async (req, res) => {
    try {
      const category = req.query.category as string;
      const popular = req.query.popular === 'true';
      
      let tests;
      if (category) {
        tests = await storage.getTestsByCategory(category);
      } else if (popular) {
        tests = await storage.getPopularTests();
      } else {
        tests = await storage.getAllTests();
      }
      
      res.status(200).json(tests);
    } catch (error) {
      console.error("Error fetching tests:", error);
      res.status(500).json({ message: "Server error fetching tests" });
    }
  });

  app.get("/api/tests/:id", async (req, res) => {
    try {
      const testId = parseInt(req.params.id);
      const test = await storage.getTestById(testId);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      res.status(200).json(test);
    } catch (error) {
      console.error("Error fetching test:", error);
      res.status(500).json({ message: "Server error fetching test" });
    }
  });

  app.get("/api/tests/:id/suggestions", async (req, res) => {
    try {
      const testId = parseInt(req.params.id);
      const suggestedTests = await storage.getSuggestedTestsForTest(testId);
      
      res.status(200).json(suggestedTests);
    } catch (error) {
      console.error("Error fetching test suggestions:", error);
      res.status(500).json({ message: "Server error fetching test suggestions" });
    }
  });

  // Doctor API Routes
  app.get("/api/doctors", async (req, res) => {
    try {
      const specialty = req.query.specialty as string;
      
      let doctors;
      if (specialty) {
        doctors = await storage.getDoctorsBySpecialty(specialty);
      } else {
        doctors = await storage.getAllDoctors();
      }
      
      res.status(200).json(doctors);
    } catch (error) {
      console.error("Error fetching doctors:", error);
      res.status(500).json({ message: "Server error fetching doctors" });
    }
  });

  app.get("/api/doctors/:id", async (req, res) => {
    try {
      const doctorId = parseInt(req.params.id);
      const doctor = await storage.getDoctorById(doctorId);
      
      if (!doctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      res.status(200).json(doctor);
    } catch (error) {
      console.error("Error fetching doctor:", error);
      res.status(500).json({ message: "Server error fetching doctor" });
    }
  });

  app.get("/api/doctors/:id/schedules", async (req, res) => {
    try {
      const doctorId = parseInt(req.params.id);
      const schedules = await storage.getDoctorSchedules(doctorId);
      
      res.status(200).json(schedules);
    } catch (error) {
      console.error("Error fetching doctor schedules:", error);
      res.status(500).json({ message: "Server error fetching doctor schedules" });
    }
  });

  // Appointment API Routes (Protected)
  app.post("/api/appointments", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Validate appointment data
      const { appointment_date, appointment_time, type, doctor_id, test_id, notes } = req.body;
      
      if (!appointment_date || !appointment_time || !type) {
        return res.status(400).json({ message: "Missing required appointment fields" });
      }
      
      if (type === 'test' && !test_id) {
        return res.status(400).json({ message: "Test ID is required for test appointments" });
      }
      
      if (type === 'consultation' && !doctor_id) {
        return res.status(400).json({ message: "Doctor ID is required for consultation appointments" });
      }
      
      // Check for conflicting appointments
      const userAppointments = await storage.getAppointmentsByUserId(userId);
      const conflictingAppointment = userAppointments.find(
        app => app.appointment_date === appointment_date && app.appointment_time === appointment_time
      );
      
      if (conflictingAppointment) {
        return res.status(400).json({ message: "You already have an appointment at this time" });
      }
      
      // Create appointment
      const appointment = await storage.createAppointment({
        user_id: userId,
        appointment_date,
        appointment_time,
        type,
        doctor_id: type === 'consultation' ? doctor_id : null,
        test_id: type === 'test' ? test_id : null,
        notes,
        status: 'pending'
      });
      
      // Create payment record
      let amount = "0.00";
      if (type === 'test' && test_id) {
        const test = await storage.getTestById(test_id);
        if (test) {
          amount = test.price;
        }
      } else if (type === 'consultation') {
        // Set default consultation fee
        amount = "120.00";
      }
      
      // Add service fee
      const serviceFee = "5.00";
      const totalAmount = (parseFloat(amount) + parseFloat(serviceFee)).toFixed(2);
      
      // Create payment with current timestamp and proper structure
      const paymentData = {
        appointment_id: appointment.id,
        amount: totalAmount,
        status: 'pending',
        payment_method: req.body.payment_method || 'pending',
        transaction_id: null,
        // Add required fields for database schema
        created_at: new Date()
      };
      
      const payment = await storage.createPayment(paymentData);
      
      // Create bill with current timestamp and proper structure
      const billData = {
        appointment_id: appointment.id,
        payment_id: payment.id,
        total_amount: totalAmount,
        pdf_url: null,
        // Add required fields for database schema
        bill_date: new Date()
      };
      
      const bill = await storage.createBill(billData);
      
      res.status(201).json({
        message: "Appointment booked successfully",
        appointment,
        payment,
        bill
      });
    } catch (error) {
      console.error("Error creating appointment:", error);
      res.status(500).json({ message: "Server error creating appointment" });
    }
  });

  app.get("/api/appointments", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const appointments = await storage.getAppointmentsByUserId(userId);
      
      // Enrich appointments with payment info
      const enrichedAppointments = await Promise.all(
        appointments.map(async (appointment) => {
          const payment = await storage.getPaymentByAppointmentId(appointment.id);
          return {
            ...appointment,
            payment: payment || { status: 'pending' }
          };
        })
      );
      
      res.status(200).json(enrichedAppointments);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ message: "Server error fetching appointments" });
    }
  });

  app.get("/api/appointments/:id", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      const appointmentId = parseInt(req.params.id);
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const appointment = await storage.getAppointmentById(appointmentId);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      if (appointment.user_id !== userId) {
        return res.status(403).json({ message: "Not authorized to view this appointment" });
      }
      
      // Get payment info
      const payment = await storage.getPaymentByAppointmentId(appointmentId);
      
      // Get bill info
      const bill = await storage.getBillByAppointmentId(appointmentId);
      
      res.status(200).json({
        appointment,
        payment,
        bill
      });
    } catch (error) {
      console.error("Error fetching appointment:", error);
      res.status(500).json({ message: "Server error fetching appointment" });
    }
  });

  app.put("/api/appointments/:id/status", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      const appointmentId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const appointment = await storage.getAppointmentById(appointmentId);
      
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      if (appointment.user_id !== userId) {
        return res.status(403).json({ message: "Not authorized to update this appointment" });
      }
      
      if (!['pending', 'confirmed', 'cancelled', 'completed'].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      await storage.updateAppointmentStatus(appointmentId, status);
      
      res.status(200).json({ message: "Appointment status updated successfully" });
    } catch (error) {
      console.error("Error updating appointment status:", error);
      res.status(500).json({ message: "Server error updating appointment status" });
    }
  });

  // Payment API Routes (Protected)
  app.put("/api/payments/:id/status", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      const paymentId = parseInt(req.params.id);
      const { status, transaction_id } = req.body;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Get all appointments for the user
      const userAppointments = await storage.getAppointmentsByUserId(userId);
      
      // Find the payment by ID through appointments
      let foundPayment = null;
      let foundAppointment = null;
      
      for (const appointment of userAppointments) {
        const payment = await storage.getPaymentByAppointmentId(appointment.id);
        if (payment && payment.id === paymentId) {
          foundPayment = payment;
          foundAppointment = appointment;
          break;
        }
      }
      
      if (!foundPayment || !foundAppointment) {
        return res.status(404).json({ message: "Payment not found or not authorized" });
      }
      
      if (!['pending', 'completed'].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      await storage.updatePaymentStatus(paymentId, status);
      
      // If payment completed, update appointment status to confirmed
      if (status === 'completed') {
        await storage.updateAppointmentStatus(foundAppointment.id, 'confirmed');
      }
      
      res.status(200).json({ message: "Payment status updated successfully" });
    } catch (error) {
      console.error("Error updating payment status:", error);
      res.status(500).json({ message: "Server error updating payment status" });
    }
  });

  // Test Results API Routes (Protected)
  app.get("/api/results", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const results = await storage.getTestResultsByUserId(userId);
      
      res.status(200).json(results);
    } catch (error) {
      console.error("Error fetching test results:", error);
      res.status(500).json({ message: "Server error fetching test results" });
    }
  });

  // Health Packages API Routes
  app.get("/api/packages", async (req, res) => {
    try {
      const packages = await storage.getAllHealthPackages();
      res.status(200).json(packages);
    } catch (error) {
      console.error("Error fetching health packages:", error);
      res.status(500).json({ message: "Server error fetching health packages" });
    }
  });
  
  // Admin Doctor Management Routes
  app.post("/api/doctors", adminMiddleware, async (req, res) => {
    try {
      const parseResult = insertDoctorSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: parseResult.error.errors 
        });
      }
      
      const doctor = await storage.createDoctor(parseResult.data);
      
      res.status(201).json({
        message: "Doctor added successfully",
        doctor
      });
    } catch (error) {
      console.error("Error creating doctor:", error);
      res.status(500).json({ message: "Server error creating doctor" });
    }
  });
  
  app.put("/api/doctors/:id", adminMiddleware, async (req, res) => {
    try {
      const doctorId = parseInt(req.params.id);
      const parseResult = insertDoctorSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: parseResult.error.errors 
        });
      }
      
      // Check if doctor exists
      const existingDoctor = await storage.getDoctorById(doctorId);
      
      if (!existingDoctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      // Update doctor
      const updatedDoctor = await storage.updateDoctor(doctorId, parseResult.data);
      
      res.status(200).json({
        message: "Doctor updated successfully",
        doctor: updatedDoctor
      });
    } catch (error) {
      console.error("Error updating doctor:", error);
      res.status(500).json({ message: "Server error updating doctor" });
    }
  });
  
  app.delete("/api/doctors/:id", adminMiddleware, async (req, res) => {
    try {
      const doctorId = parseInt(req.params.id);
      
      // Check if doctor exists
      const existingDoctor = await storage.getDoctorById(doctorId);
      
      if (!existingDoctor) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      // Delete doctor
      await storage.deleteDoctor(doctorId);
      
      res.status(200).json({
        message: "Doctor deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting doctor:", error);
      res.status(500).json({ message: "Server error deleting doctor" });
    }
  });

  // Generate PDF bill
  app.get("/api/bills/:id/pdf", authMiddleware, async (req, res) => {
    try {
      const userId = req.user?.userId;
      const billId = parseInt(req.params.id);
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Get all appointments for the user to find the bill
      const userAppointments = await storage.getAppointmentsByUserId(userId);
      
      // Find the bill by ID through appointments
      let foundBill = null;
      for (const appointment of userAppointments) {
        const bill = await storage.getBillByAppointmentId(appointment.id);
        if (bill && bill.id === billId) {
          foundBill = bill;
          break;
        }
      }
      
      if (!foundBill) {
        return res.status(404).json({ message: "Bill not found" });
      }
      
      const appointment = await storage.getAppointmentById(foundBill.appointment_id);
      if (!appointment || appointment.user_id !== userId) {
        return res.status(403).json({ message: "Not authorized to access this bill" });
      }
      
      // Generate bill details for PDF
      const payment = await storage.getPaymentByAppointmentId(appointment.id);
      let test;
      let doctor;
      
      if (appointment.test_id) {
        test = await storage.getTestById(appointment.test_id);
      }
      
      if (appointment.doctor_id) {
        doctor = await storage.getDoctorById(appointment.doctor_id);
      }
      
      const user = await storage.getUser(userId);
      
      // Return bill details in a format suitable for client-side PDF generation
      res.status(200).json({
        billId: foundBill.id,
        billDate: format(new Date(foundBill.bill_date || new Date()), 'MMM dd, yyyy'),
        patientName: user?.name || 'Patient',
        patientEmail: user?.email || 'patient@example.com',
        appointmentDate: format(new Date(appointment.appointment_date), 'MMM dd, yyyy'),
        appointmentTime: appointment.appointment_time,
        type: appointment.type,
        test: test || null,
        doctor: doctor || null,
        amount: payment?.amount || foundBill.total_amount,
        status: payment?.status || 'pending'
      });
    } catch (error) {
      console.error("Error generating bill PDF:", error);
      res.status(500).json({ message: "Server error generating bill PDF" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
